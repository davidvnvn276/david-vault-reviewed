# Publication-scope correction, 16 October 2026

## Reason for the correction

The earlier withdrawal-focused headline could be read as describing a customer incident involving a newly announced product. The evidence does not establish that connection. The revised publication asks how batch settlement works and identifies local-fork/mock-asset scope before presenting its numerical example.

Primary context source: [Rayls launch-deposits announcement](https://www.rayls.com/blog/first-vault-on-rayls-launch-deposits-open), published 15 October 2026 and reviewed 16 October 2026.

The announcement concerns BRL1.p launch deposits before investment-vault transfers. The experiment does not establish the intended withdrawal behavior of that product or authenticate a mapping from the tested mREAL deployment to its contracts.

## What changed

- Both publication titles, opening scope paragraphs and explanatory conclusions now focus on batch settlement.
- The public context source is linked in both articles.
- The graphics identify the local mock-asset experiment and state that BRL1.p launch deposits were not tested.
- The comparison graphics display B's claimable amount after settlement. The separate accounting graphic and retained receipts establish subsequent token transfers.
- Public-facing README and review guidance reflect the revised scope. The public evidence link is now included in the manuscript.

## What did not change

No mainnet or local EVM experiment was added for this editorial correction. The five outcomes, raw receipts, before/after states, fork blocks, source comparisons, exact arithmetic and original 174-entry evidence manifest are unchanged. Archived files under original-evidence retain their original wording for provenance; use the revised root manuscript for publication.

The production role of the inspected deployment remains unconfirmed. Identical infrastructure names or similar mechanisms do not authenticate product-contract identity, investor rights, product readiness or real-world asset backing.
