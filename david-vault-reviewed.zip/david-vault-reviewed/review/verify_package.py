#!/usr/bin/env python3
"""Verify the reviewed distribution, then run the unchanged original verifier."""
import hashlib
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
lines = (ROOT / 'SHA256SUMS-reviewed.txt').read_text().splitlines()
count = 0
for line in lines:
    expected, relative = line.split('  ', 1)
    target = (ROOT / relative).resolve()
    if not target.is_relative_to(ROOT) or not target.is_file():
        raise SystemExit('Missing or unsafe manifest path: ' + relative)
    if hashlib.sha256(target.read_bytes()).hexdigest() != expected:
        raise SystemExit('Hash mismatch: ' + relative)
    count += 1
print(f'PASS {count} reviewed distribution files match the manifest', flush=True)
subprocess.run([sys.executable, str(ROOT / 'original-evidence/verify_saved.py')], check=True)
