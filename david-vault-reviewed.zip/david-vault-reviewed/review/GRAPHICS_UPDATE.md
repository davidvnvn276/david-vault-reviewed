# Graphics integrity correction, 16 October 2026

A rendered scenario-matrix PNG in the previous graphics update was truncated. The original standalone matrix image was complete. This update re-renders all three figures and checks full PNG decoding before installing each output.

The renderer now exports to a new temporary filename, fully decodes the PNG with Pillow, checks its dimensions, and atomically replaces the destination only after those checks pass. The exported pixels are native SVG renders; no figures or test results are synthesized.

The reviewed distribution's checksum manifest is refreshed. The original 174-entry evidence manifest and its source, RPC records, receipts, scripts and results are unchanged. This correction concerns figure-file integrity, not contract behavior or the reported experiment.
