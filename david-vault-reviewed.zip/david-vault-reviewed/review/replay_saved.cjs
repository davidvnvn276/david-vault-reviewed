/* Re-execute the original harness against preserved upstream replies.
 * No live RPC fallback exists. This checks EVM reproducibility, not RPC authenticity.
 * Usage, from package root:
 * node review/replay_saved.cjs review-results/replay-01
 */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const ROOT = path.resolve(__dirname, '..');
const ORIGINAL = path.join(ROOT, 'original-evidence');
const OUT = path.resolve(process.argv[2] || path.join(ROOT, 'replay-01'));
fs.mkdirSync(path.dirname(OUT), {recursive:true});
assert.ok(!fs.existsSync(OUT), 'Choose a new output directory');
const saved = JSON.parse(fs.readFileSync(path.join(ORIGINAL, 'data/local-fork/upstream-read-journal.json')));
const canonical = x => Array.isArray(x) ? x.map(canonical) : x && typeof x === 'object' ? Object.fromEntries(Object.keys(x).sort().map(k=>[k,canonical(x[k])])) : x;
const key = r => JSON.stringify(canonical([r.method, r.params || []]));
const replies = new Map();
for (const row of saved) {
  const value = {...row.response}; delete value.id;
  const k = key(row.request);
  if (replies.has(k)) assert.deepEqual(replies.get(k), value, 'Conflicting saved replies');
  replies.set(k,value);
}
// The original used ten unused randomly generated Ganache wallets. Their new
// addresses have no saved nonce replies. Omit these unused wallets instead of
// inventing missing state. All five explicitly unlocked test identities stay.
const ganache = require(path.join(ORIGINAL,'fork/node_modules/ganache'));
const createProvider = ganache.provider;
Object.defineProperty(ganache,'provider',{configurable:true,enumerable:true,
  value:options=>createProvider({...options,wallet:{...options.wallet,totalAccounts:0}})});
let served=0;
global.fetch = async (url, options) => {
  assert.equal(String(url), 'https://mainnet-rpc.rayls.com/');
  assert.equal(options.method, 'POST');
  const request=JSON.parse(options.body), response=replies.get(key(request));
  if (!response) throw Error('Saved-state replay has no response for '+key(request));
  served++;
  return new Response(JSON.stringify({...response,id:request.id}), {status:200,headers:{'Content-Type':'application/json'}});
};
process.argv[2]=OUT;
process.on('beforeExit',()=>{
  if(process.exitCode) return;
  try {
    const original=JSON.parse(fs.readFileSync(path.join(ORIGINAL,'data/local-fork/summary.json')));
    const replay=JSON.parse(fs.readFileSync(path.join(OUT,'summary.json')));
    assert.equal(replay.status,'passed');
    assert.equal(replay.fork_block_hash, original.fork_block_hash);
    assert.deepEqual(replay.initial, original.initial);
    for(let i=0;i<original.scenarios.length;i++) {
      const a=original.scenarios[i], b=replay.scenarios[i];
      for(const field of ['label','cash_raw','cancel_A','before','settled','final']) assert.deepEqual(b[field],a[field],a.label+' '+field);
      const economicEvents = events => events.filter(e=>e.event!=='TotalAssetsExpirationUpdated');
      assert.deepEqual(economicEvents(b.events),economicEvents(a.events),a.label+' economic events');
    }
    const report={status:'passed',mode:'saved upstream state, actual local EVM execution',fork_block:replay.fork_block,
      fork_hash:replay.fork_block_hash,scenarios:replay.scenarios.length,all_scenario_states_match_original:true,
      all_economic_settlement_events_match_original:true,unique_saved_replies:replies.size,served_reads:served,
      no_network_fallback:true,local_chain_id:replay.local_chain_id,
      provider_adjustment:'Omit unused random default wallets (wallet.totalAccounts=0); original harness bytes and all explicitly unlocked test identities unchanged.',
      limit:'Re-execution depends on supplied RPC replies; it does not independently authenticate mainnet state. Local timestamps and transaction hashes may differ.'};
    fs.writeFileSync(path.join(OUT,'replay-comparison.json'),JSON.stringify(report,null,2)+'\n');
    console.error('PASS: five scenarios re-executed in the EVM; states and economic settlement events match.');
  } catch(e) { console.error(e.stack); process.exitCode=1; }
});
require(path.join(ORIGINAL,'fork/fork_probe.cjs'));
