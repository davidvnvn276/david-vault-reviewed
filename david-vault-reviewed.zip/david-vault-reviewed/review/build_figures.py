#!/usr/bin/env python3
"""Draw precise evidence figures as outlined SVG; render with Inkscape.
Requires fontTools and the named system fonts. No generative data or screenshots.
"""
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
import base64
import hashlib
import html
import json
import subprocess

ROOT = Path(__file__).resolve().parent.parent
FIG = ROOT / 'figures'
FIG.mkdir(exist_ok=True)
LOGO = FIG / 'assets/rayls-mark.png'
assert hashlib.sha256(LOGO.read_bytes()).hexdigest() == '75e95e00b76d284facc82f1bd67f9abe344df454349d39d9a3a111293a7041b1'
FONT_PATHS = {
    'regular': '/usr/share/fonts/opentype/urw-base35/NimbusSans-Regular.otf',
    'bold': '/usr/share/fonts/opentype/urw-base35/NimbusSans-Bold.otf',
    'mono': '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf',
}
FONTS = {k: TTFont(p) for k, p in FONT_PATHS.items()}
C = {'bg':'#F0F1F7','grid':'#DFE1EB','ink':'#121217','muted':'#686879',
     'purple':'#7652E8','lilac':'#B89DFF','acid':'#EDFF31','white':'#FFFFFF','pale':'#EAE4FA'}
SPEC = []

def width(s,size,font):
    f=FONTS[font]; cmap=f.getBestCmap(); hm=f['hmtx'].metrics; upm=f['head'].unitsPerEm
    return sum(hm[cmap[ord(c)]][0] for c in s)*size/upm

class Canvas:
    def __init__(self,name,h,title):
        self.name=name;self.h=h;self.items=[];self.boxes=[]
        self.items.append(f'<title>{html.escape(title)}</title>')
        self.items.append('<defs><pattern id="grid" width="36" height="36" patternUnits="userSpaceOnUse"><path d="M36 0H0V36" fill="none" stroke="#DFE1EB" stroke-width="0.7"/></pattern><marker id="arrow" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto" markerUnits="userSpaceOnUse"><path d="M0 0L10 5L0 10Z" fill="#7652E8"/></marker></defs>')
        self.rect(0,0,2000,h,C['bg']);self.rect(0,0,2000,h,'url(#grid)')
        self.poly([(1510,0),(2000,0),(2000,255),(1740,255),(1510,65)],C['lilac'])
        self.poly([(0,h-170),(250,h-170),(420,h),(0,h)],C['acid'])
        self.rect(0,0,560,7,C['purple']);self.rect(560,0,250,7,C['acid'])
        self.poly([(1774,24),(1960,24),(1960,210),(1795,210),(1774,189)],C['ink'])
        b64=base64.b64encode(LOGO.read_bytes()).decode()
        self.items.append(f'<image x="1786" y="36" width="162" height="162" xlink:href="data:image/png;base64,{b64}"/>')
    def rect(self,x,y,w,h,fill,stroke=None,sw=2):
        self.items.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}"'+(f' stroke="{stroke}" stroke-width="{sw}"' if stroke else '')+'/>')
    def poly(self,points,fill,stroke=None):
        self.items.append('<polygon points="'+' '.join(f'{x},{y}' for x,y in points)+f'" fill="{fill}"'+(f' stroke="{stroke}" stroke-width="2"' if stroke else '')+'/>')
    def line(self,x1,y1,x2,y2,color=None,sw=2,arrow=False):
        self.items.append(f'<path d="M{x1},{y1}L{x2},{y2}" fill="none" stroke="{color or C["ink"]}" stroke-width="{sw}"'+(' marker-end="url(#arrow)"' if arrow else '')+'/>')
    def path(self,d,color,sw=3,arrow=False):
        self.items.append(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{sw}"'+(' marker-end="url(#arrow)"' if arrow else '')+'/>')
    def text(self,x,y,s,size=32,font='regular',fill=None,maxw=None):
        w=width(s,size,font)
        if maxw is not None: assert w<=maxw,(self.name,s,w,maxw)
        assert x>=0 and y-size>=0 and x+w<=2000 and y+size*.25<=self.h,(self.name,s,x,y,w)
        f=FONTS[font];gs=f.getGlyphSet();cmap=f.getBestCmap();scale=size/f['head'].unitsPerEm
        parts=[];pos=0
        for c in s:
            g=cmap[ord(c)];pen=SVGPathPen(gs);gs[g].draw(pen);d=pen.getCommands()
            if d:parts.append(f'<path transform="translate({pos:.4f} 0)" d="{d}"/>')
            pos+=f['hmtx'].metrics[g][0]
        self.items.append(f'<g fill="{fill or C["ink"]}" transform="translate({x} {y}) scale({scale:.8f} {-scale:.8f})"><title>{html.escape(s)}</title>'+''.join(parts)+'</g>')
        self.boxes.append({'text':s,'x':x,'baseline':y,'font_size':size,'font':font,'advance_width':round(w,3)})
    def ribbon(self,y,s):
        self.poly([(70,y),(1880,y),(1910,y+29),(1880,y+58),(70,y+58)],C['ink'])
        self.text(94,y+41,s,36,'bold',C['white'],1740)
    def footer(self,s):
        self.text(72,self.h-25,s,24,'regular',C['muted'],1850)
    def save(self,description):
        svg=FIG/(self.name+'.svg')
        svg.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="2000" height="{self.h}" viewBox="0 0 2000 {self.h}">\n'+'\n'.join(self.items)+'\n</svg>\n')
        subprocess.run(['inkscape',str(svg),'--export-width=3200',f'--export-filename={FIG/(self.name+".png")}'],check=True,capture_output=True)
        subprocess.run(['inkscape',str(svg),'--export-width=500',f'--export-filename={FIG/(self.name+"-preview.png")}'],check=True,capture_output=True)
        SPEC.append({'figure':self.name,'svg_dimensions':[2000,self.h],'png_dimensions':[3200,int(self.h*1.6)],'description':description,'text_bounds':self.boxes})

def banner():
    c=Canvas('01-banner',800,'Same Safe liquidity, different redemption batch: a local Rayls vault test')
    c.text(72,62,'LOCAL FORK STUDY',28,'mono',C['purple'])
    c.text(70,155,'Successful call.',87,'bold',maxw=940)
    c.text(70,253,'Still pending.',104,'bold',maxw=940)
    c.text(73,315,"Why B’s 495 mREAL stayed in the queue.",33,maxw=830)
    c.poly([(72,370),(805,370),(837,402),(837,656),(72,656)],C['ink'])
    c.text(106,418,'SAFE LIQUIDITY IN BOTH TESTS',29,'mono',C['lilac'],690)
    c.text(100,567,'1,000',150,'bold',C['acid'])
    c.text(555,566,'mREAL',48,'bold',C['white'],230)
    c.text(107,626,'Existing mock asset · local execution',29,'regular',C['white'],680)
    # The comparison is the evidence, not a decorative title card.
    for y,title,required,shares,payment,positive in [
        (234,'A + B IN CURRENT BATCH','5,445','5,500 pending shares','B received 0 mREAL',False),
        (458,'AFTER A CANCELS BEFORE VALUATION','495','500 pending shares','B received 495 mREAL',True)]:
        c.rect(936,y,984,198,C['white'],C['purple'])
        c.rect(936,y,984,46,C['acid'] if positive else C['ink'])
        c.text(960,y+33,title,27,'mono',C['ink'] if positive else C['white'],920)
        c.text(962,y+112,required,74,'bold',C['purple'],330)
        c.text(1278,y+102,'mREAL needed',28,'regular',maxw=310)
        c.text(963,y+151,shares,26,'regular',C['muted'],480)
        c.text(963,y+186,payment,30,'bold',maxw=570)
        c.rect(1615,y+70,278,58,C['purple'] if positive else C['pale'])
        c.text(1640,y+111,'CLAIMED' if positive else 'PENDING',31,'bold',C['white'] if positive else C['purple'],230)
    c.ribbon(694,'Same liquidity. Smaller batch. Different outcome.')
    c.footer('Controlled mock-asset tests · original fork block 12,557,717 · not production withdrawal evidence')
    c.save('Causal comparison: B received zero with A+B pending, then 495 mREAL after A cancelled at the same 1,000-mREAL Safe liquidity.')

def matrix():
    c=Canvas('02-scenario-matrix',1125,'Five local scenarios: settlement receipt success is distinct from settlement and payment')
    c.text(70,104,'Five tests.',76,'bold',maxw=1450)
    c.text(70,186,'Only two batches settled.',74,'bold',maxw=1600)
    c.text(73,244,'A requests 5,000 shares · B requests 500 · exit fee 1% · underlying: mock mREAL',31,maxw=1660)
    xs=[70,420,795,1115,1320,1530,1920]
    top=302;hh=80;rh=112
    c.rect(70,top,1850,hh+5*rh,C['white'],C['ink'])
    c.rect(70,top,1850,hh,C['ink'])
    for x,s in [(92,'Scenario'),(442,'Safe liquidity'),(817,'Batch needs'),(1137,'Receipt'),(1342,'Settlement'),(1552,'B paid later')]:
        c.text(x,top+37,s,29,'bold',C['white'],(xs[xs.index(x-22)+1]-(x-22)-36) if x-22 in xs else 340)
    for x,s in [(442,'mREAL'),(817,'mREAL'),(1137,'status'),(1342,'event'),(1552,'mREAL')]:c.text(x,top+65,s,24,'regular',C['lilac'])
    rows=[('01  Zero cash','0','5,445','No','0',False),
          ('02  B fits alone','1,000','5,445','No','0',False),
          ('03  One unit short','5,445 minus','5,445','No','0',False),
          ('04  Exact threshold','5,445','5,445','Yes','495',True),
          ('05  A cancels','1,000','495','Yes','495',True)]
    for i,(label,cash,required,event,paid,yes) in enumerate(rows):
        y=top+hh+i*rh
        c.rect(71,y,1848,rh,C['pale'] if yes else C['white'])
        c.rect(71,y,8,rh,C['purple'] if not yes else C['acid'])
        c.line(70,y+rh,1920,y+rh,'#C8C5D8',1)
        c.text(92,y+66,label,30,'bold',maxw=310)
        if i==2:
            c.text(442,y+47,cash,36,'bold',maxw=335);c.text(442,y+83,'1 smallest unit',26,'mono',C['purple'],330)
        else:c.text(442,y+69,cash,44,'bold',maxw=335)
        c.text(817,y+69,required,44,'bold',C['purple'],280)
        c.text(1150,y+70,'1',46,'mono')
        c.text(1360,y+69,event,37,'bold',C['purple'] if yes else C['muted'],160)
        c.text(1560,y+72,paid,54,'bold',C['ink'],300)
    c.ribbon(975,'Status 1 did not establish settlement or payment.')
    c.text(73,1071,'One unit = 0.000000000000000001 mREAL. “Event” means SettleRedeem.',25,'regular',C['muted'],1850)
    c.footer('A cancels before the valuation proposal · original fork block 12,557,717 · local tests, mock asset')
    c.save('All five controlled outcomes. Every settlement receipt had status 1; only the exact threshold and cancellation control produced a settlement and a later B payment.')

def accounting():
    c=Canvas('03-cash-and-shares',1125,'Exact-threshold accounting: mREAL transfers and vault-share supply are separate')
    c.text(70,110,'Follow the tokens.',72,'bold',maxw=1600)
    c.text(70,188,'Reconcile the shares.',72,'bold',maxw=1600)
    c.text(73,246,'Exact-threshold scenario · raw transfer logs and before/after balances',31,maxw=1660)
    for x,w,s in [(70,865,'UNDERLYING TOKENS · mREAL'),(990,930,'VAULT SHARE SUPPLY')]:
        c.rect(x,296,w,635,C['white'],C['ink']);c.rect(x,296,w,61,C['ink']);c.text(x+25,338,s,30,'mono',C['white'],w-50)
    # Separate asset balances. No generic coin symbols or invented token art.
    for x,label,n,sub in [(105,'SAFE','5,445','mREAL sent'),(567,'VAULT','5,445','mREAL received')]:
        c.poly([(x,395),(x+305,395),(x+325,415),(x+325,542),(x,542)],C['pale'],C['purple'])
        c.text(x+20,430,label,26,'mono',C['purple'],280)
        c.text(x+18,491,n,62,'bold',maxw=290);c.text(x+20,526,sub,27,maxw=285)
    c.line(435,470,546,470,C['purple'],4,True)
    c.text(441,443,'settle',22,'mono',C['purple'])
    c.path('M729 543 V586 H267 V644',C['purple'],3,True)
    c.path('M729 586 V644',C['purple'],3,True)
    c.text(352,619,'separate claims',25,'mono',C['purple'],330)
    for x,label,n in [(105,'CONTROLLER A','4,950'),(567,'CONTROLLER B','495')]:
        c.rect(x,665,325,145,C['acid'] if label.endswith('B') else C['white'],C['purple'])
        c.text(x+19,702,label,25,'mono',C['purple'],290)
        c.text(x+18,766,n,64,'bold',maxw=290);c.text(x+20,797,'mREAL received',26,maxw=290)
    c.text(104,882,'Vault mREAL after claims: 0',38,'bold',maxw=805)
    # Share-token quantities are independently reconciled, not cash amounts.
    for y,n,label,fill in [(434,'11,000','initial shares',C['ink']),
                           (554,'− 5,500','pending shares burned',C['purple']),
                           (674,'+ 55','fee shares minted',C['purple'])]:
        c.text(1025,y,n,65,'bold',fill,390);c.text(1405,y-6,label,31,'regular',maxw=480)
    c.line(1025,717,1882,717,C['ink'],2)
    c.rect(1015,748,880,112,C['ink']);c.text(1040,831,'5,555',87,'bold',C['acid'],380)
    c.text(1410,804,'shares outstanding',34,'bold',C['white'],450)
    c.text(1025,898,'Fee mints total 55 shares, not 55 mREAL.',29,'regular',C['muted'],850)
    c.ribbon(975,'Asset transfers and share supply reconcile separately.')
    c.footer('Local EVM execution · mock mREAL · original fork block 12,557,717 · not real-asset redemption evidence')
    c.save('Exact-threshold reconciliation: Safe to vault 5,445 mREAL; claims pay 4,950 and 495. Independently, 11,000 shares minus 5,500 burned plus 55 fee shares leaves 5,555.')

banner();matrix();accounting()
(FIG/'figure-specifications.json').write_text(json.dumps({'palette':C,'fonts':FONT_PATHS,'logo_sha256':hashlib.sha256(LOGO.read_bytes()).hexdigest(),'figures':SPEC},indent=2)+'\n')
print('PASS: three outlined SVGs, 3200-pixel PNGs and 500-pixel previews; all text advances checked.')
