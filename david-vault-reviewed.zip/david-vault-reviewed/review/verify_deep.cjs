/* Independent saved-record review. No RPC, signing, or transaction submission.
 * Requires the original locked ethers installation. Run from package root:
 * node review/verify_deep.cjs [optional local-fork result directory]
 */
const fs=require('node:fs'), path=require('node:path'), crypto=require('node:crypto');
const {Interface,keccak256}=require('../original-evidence/fork/node_modules/ethers');
const ROOT=path.resolve(__dirname,'..'), O=path.join(ROOT,'original-evidence');
const read=f=>JSON.parse(fs.readFileSync(f,'utf8'));
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const U=10n**18n, ZERO='0x'+'0'.repeat(40);
const V='0xcc180cb4031de7c2ec3d4c16e36ede4c6550eda0';
const IMPL='0xd04deaba7fd06634764cbffe140011c69063ac77';
const A='0x4d76d208692c1b1c22d77350b89396d76c947e22';
const B='0xc7e33057e72a5331e9ecbdd8159995de6c78f554';
const meta=read(path.join(O,'lagoon-logic-source.json'));
const vi=new Interface(meta.abi);
const eventsSource=meta.additional_sources.find(s=>s.file_path==='src/v0.6.0/primitives/Events.sol').source_code;
const declaration=eventsSource.match(/event SettleRedeem\([\s\S]*?\);/)[0].replace(/;$/,'');
const ei=new Interface([declaration,'event Transfer(address indexed from,address indexed to,uint256 value)',
  'event TotalAssetsExpirationUpdated(uint128 oldExpiration,uint128 newExpiration)']);
const checks=[];
function ok(label,test){if(!test)throw Error('FAIL: '+label);checks.push(label);}
const byId=x=>new Map(x.map(r=>[r.id,r]));
function boundBatch(dir,prefix,tag){
  const req=read(path.join(dir,prefix+'-request.json')), res=byId(read(path.join(dir,prefix+'-response.json')));
  ok(prefix+' request/response IDs unique',new Set(req.map(r=>r.id)).size===req.length&&res.size===req.length);
  for(const r of req){ok(prefix+' response ID '+r.id,res.has(r.id));ok(prefix+' pinned block '+r.id,r.params.at(-1)===tag);}
  return {req,res};
}
function mainnet(dir){
  const s=read(path.join(dir,'summary.json'));
  const initial=byId(read(path.join(dir,'initial-response.json'))), head=initial.get(2).result;
  ok('mainnet chain ID',BigInt(initial.get(1).result)===72957n);
  ok('mainnet header binding',Number(BigInt(head.number))===s.block&&head.hash===s.block_hash);
  ok('mainnet timestamp binding',new Date(Number(BigInt(head.timestamp))*1000).toISOString()===new Date(s.block_timestamp_utc).toISOString());
  const {req,res}=boundBatch(dir,'state',head.number), labels=read(path.join(dir,'state-labels.json'));
  const rows=new Map(labels.map((l,i)=>[l,{r:req[i],v:res.get(req[i].id)}]));
  for(const [fn,field] of [['name','name'],['symbol','symbol'],['version','version'],['asset','asset'],['safe','safe'],['totalSupply','total_supply_raw'],['totalAssets','total_assets_raw']]){
    const row=rows.get(fn+'()');ok('selector '+fn,row.r.method==='eth_call'&&row.r.params[0].to===V&&row.r.params[0].data===vi.encodeFunctionData(fn));
    const value=vi.decodeFunctionResult(fn,row.v.result)[0].toString();ok('decode '+field,value.toLowerCase()===s[field].toLowerCase());
  }
  const slot=rows.get('implementation-slot');
  ok('EIP-1967 slot identity',slot.r.method==='eth_getStorageAt'&&slot.r.params[1]==='0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc');
  ok('EIP-1967 implementation address','0x'+slot.v.result.slice(-40)===IMPL&&s.implementation===IMPL);
  const fees=vi.decodeFunctionResult('feeRates',rows.get('feeRates()').v.result)[0];
  ok('exit fee 100 bps',fees.exitRate===100n);
  const b=boundBatch(dir,'balances',head.number), bl=read(path.join(dir,'balances-labels.json'));
  const br=new Map(bl.map((l,i)=>[l,{r:b.req[i],v:b.res.get(b.req[i].id)}]));
  const assetI=new Interface(['function name() view returns (string)','function symbol() view returns (string)','function decimals() view returns (uint8)']);
  for(const [fn,expected] of [['name','Mock Real Stable Coin'],['symbol','mREAL'],['decimals',18n]]){
    const row=br.get('asset-'+fn+'()');ok('asset '+fn+' selector',row.r.params[0].to===s.asset&&row.r.params[0].data===assetI.encodeFunctionData(fn));
    ok('asset '+fn+' decoded',assetI.decodeFunctionResult(fn,row.v.result)[0]===expected);
  }
  const runtime=br.get('implementation-code');ok('runtime address',runtime.r.method==='eth_getCode'&&runtime.r.params[0]===IMPL);
  const explorer=read(path.join(dir,'implementation-explorer.json'));
  ok('RPC runtime equals Explorer runtime',runtime.v.result.toLowerCase()===explorer.deployed_bytecode.toLowerCase());
  ok('runtime SHA256 recomputed',sha(Buffer.from(runtime.v.result.slice(2),'hex'))===s.runtime_sha256);
}
function sources(){
  const original=read(path.join(O,'data/github-pinned-sources.json'));
  const explorer=new Map([[meta.file_path,meta.source_code],...meta.additional_sources.map(s=>[s.file_path,s.source_code])]);
  const recorded=read(path.join(O,'data/source-comparison.json'));
  for(const f of original.files){
    const fresh=fs.readFileSync(path.join(ROOT,'review/sources',path.basename(f.path)),'utf8');
    const c=recorded.checks.find(c=>c.path===f.path);
    ok('fresh/saved/explorer exact source '+f.path,fresh===f.content&&fresh===explorer.get(f.path));
    ok('source SHA256 recomputed '+f.path,sha(fresh)===c.github_sha256&&sha(explorer.get(f.path))===c.explorer_sha256);
  }
  const codeMap=dir=>new Map(read(path.join(dir,'upstream-read-journal.json')).filter(x=>x.request.method==='eth_getCode').map(x=>[x.request.params[0].toLowerCase(),x.response.result]));
  const old=codeMap(path.join(O,'data/local-fork')), fresh=codeMap(path.join(ROOT,'review-results/fresh-local-fork'));
  for(const addr of [V,IMPL,...meta.external_libraries.map(x=>x.address_hash.toLowerCase()).filter(a=>old.has(a))])
    ok('old/new captured runtime stable '+addr,old.get(addr)!=='0x'&&old.get(addr)===fresh.get(addr));
  // The implementation's published metadata includes these library sources.
  // Separate smart-contract metadata lookups for library addresses returned 404.
  // We compare executed runtime bytes across captures above; we do not claim
  // a fresh independent source/bytecode verification for each linked library.
}
function auditFork(dir){
  const s=read(path.join(dir,'summary.json')), tag='0x'+s.fork_block.toString(16);
  ok('local fork scope',s.original_chain_id===72957&&s.local_chain_id===31337);
  const journal=read(path.join(dir,'upstream-read-journal.json'));
  const head=journal.find(x=>x.request.method==='eth_getBlockByNumber'&&x.response.result?.number===tag)?.response.result;
  ok('fork header/hash binding',head&&head.hash===s.fork_block_hash);
  const rawCode=journal.find(x=>x.request.method==='eth_getCode'&&x.request.params[0].toLowerCase()===IMPL)?.response.result;
  ok('fork implementation Keccak recomputed',keccak256(rawCode)===s.implementation_runtime_keccak);
  ok('five scenarios',s.scenarios.length===5);
  ok('initial share accounting',BigInt(s.initial.walletA)+BigInt(s.initial.walletB)+BigInt(s.initial.pendingA)+BigInt(s.initial.pendingB)===BigInt(s.initial.supply));
  const parse=(r,name,address)=>r.logs.filter(l=>l.address.toLowerCase()===address).map(l=>{try{return ei.parseLog(l);}catch{return null;}}).filter(e=>e?.name===name);
  const transfers=(r,address,from,to)=>parse(r,'Transfer',address).filter(e=>(from===null||e.args.from.toLowerCase()===from)&&(to===null||e.args.to.toLowerCase()===to)).reduce((n,e)=>n+e.args.value,0n);
  const results=[];
  for(const c of s.scenarios){
    const prefix='cash-'+c.label, r=read(path.join(dir,prefix+'-settle-receipt.json'));
    const be=c.before, st=c.settled, end=c.final, pending=BigInt(be.pendingA)+BigInt(be.pendingB);
    const fee=(pending*100n+9999n)/10000n, required=pending-fee;
    const succeeds=c.label==='threshold'||c.cancel_A;
    ok(c.label+' settlement from Safe to vault',r.from.toLowerCase()===s.safe&&r.to.toLowerCase()===V&&r.status==='0x1');
    const se=parse(r,'SettleRedeem',V);
    ok(c.label+' raw SettleRedeem topic count',se.length===(succeeds?1:0));
    ok(c.label+' valuation expiration raw log',parse(r,'TotalAssetsExpirationUpdated',V).length===1);
    ok(c.label+' supply math',BigInt(st.supply)===BigInt(be.supply)-(succeeds?pending-fee:0n));
    ok(c.label+' burnt shares raw Transfer',transfers(r,V,null,ZERO)===(succeeds?pending:0n));
    ok(c.label+' fee shares raw mint',transfers(r,V,ZERO,null)===(succeeds?fee:0n));
    const cash=succeeds?required:0n;
    ok(c.label+' Safe to vault raw cash transfer',transfers(r,s.asset,s.safe,V)===cash);
    ok(c.label+' Safe and vault balance deltas',BigInt(be.assetSafe)-BigInt(st.assetSafe)===cash&&BigInt(st.assetVault)-BigInt(be.assetVault)===cash);
    if(succeeds){ok(c.label+' SettleRedeem raw fields',se[0].args.assetsWithdrawed===cash&&se[0].args.sharesBurned===pending&&se[0].args.totalSupply===BigInt(st.supply)&&se[0].args.totalAssets===BigInt(st.nav));}
    for(const [who,address] of [['A',A],['B',B]]){
      const payable=succeeds?BigInt(be['pending'+who])*99n/100n:0n;
      ok(c.label+' '+who+' claimable read',BigInt(st['claimable'+who])===payable);
      ok(c.label+' '+who+' pending transition',BigInt(st['pending'+who])===(succeeds?0n:BigInt(be['pending'+who])));
      const claim=read(path.join(dir,prefix+'-claim-'+who+(payable?'':'-unavailable')+'-receipt.json'));
      ok(c.label+' '+who+' claim receipt status',claim.status===(payable?'0x1':'0x0'));
      ok(c.label+' '+who+' actual asset transfer',transfers(claim,s.asset,V,address)===payable&&BigInt(end['asset'+who])-BigInt(st['asset'+who])===payable);
      ok(c.label+' '+who+' final claimable zero',BigInt(end['claimable'+who])===0n);
    }
    ok(c.label+' final vault cash zero',BigInt(end.assetVault)===0n);
    results.push({scenario:c.label,settlement_status:r.status,raw_settlement_events:se.length,safe_cash_raw:be.assetSafe,
      batch_requirement_raw:required.toString(),claimable_A_raw:st.claimableA,claimable_B_raw:st.claimableB,final_supply_raw:end.supply,final_safe_cash_raw:end.assetSafe});
  }
  ok('one smallest-unit threshold',BigInt(s.scenarios[2].cash_raw)+1n===BigInt(s.scenarios[3].cash_raw));
  ok('constant-cash cancellation control',s.scenarios[1].cash_raw===s.scenarios[4].cash_raw&&s.scenarios[1].settled.claimableB==='0'&&s.scenarios[4].settled.claimableB===(495n*U).toString());
  for(const who of ['A','B']){
    const r=read(path.join(dir,'cancel-'+who+'-receipt.json')), after=read(path.join(dir,'after-cancel-'+who+'.json'));
    ok('authorized cancellation '+who,r.status==='0x1'&&BigInt(after['wallet'+who])-BigInt(s.initial['wallet'+who])===BigInt(s.initial['pending'+who]));
    ok('cancellation pays no underlying '+who,after.assetA===s.initial.assetA&&after.assetB===s.initial.assetB&&after.supply===s.initial.supply);
  }
  for(const label of ['cancel-outsider','claim-before-settlement'])ok(label+' raw reverted receipt',read(path.join(dir,label+'-receipt.json')).status==='0x0');
  return {fork_block:s.fork_block,fork_hash:s.fork_block_hash,scenarios:results};
}
sources();mainnet(path.join(O,'data/mainnet-read'));mainnet(path.join(ROOT,'review-results/fresh-mainnet'));
const targets=process.argv[2]?[path.resolve(process.argv[2])]:[path.join(O,'data/local-fork'),path.join(ROOT,'review-results/replay-final'),path.join(ROOT,'review-results/fresh-local-fork')];
const forks=targets.map(auditFork);
const report={status:'passed',review:'Separate reviewer verifier; raw receipt topics, exact integer state and decoded RPC bindings',forks,
  checks,scope:'Consistency and EVM reproducibility, not independent consensus authentication, operator attribution, a compiler rebuild or real-asset redemption.'};
const out=path.join(ROOT,'review-results',process.argv[2]?'additional-fork-audit.json':'independent-audit.json');
fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');
console.log('PASS: source bytes, RPC bindings, deployed runtimes, raw events, five scenarios and cash/share reconciliation.');
console.log('Reviewed fork blocks: '+forks.map(f=>f.fork_block).join(', '));
console.log('Program checks are not independent experiments. Report: '+path.relative(ROOT,out));
