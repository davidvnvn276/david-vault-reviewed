# Review of DAVID's Rayls/Lagoon withdrawal investigation

## Conclusion

The supplied evidence supports the central batch-liquidity finding. No contradiction was found in the five published outcomes after exact-integer accounting, fresh source retrieval, raw-log review and a fresh five-scenario execution. This is a bounded verification result, not a claim of 100% correctness of the protocol or independent authentication of all historical state.

## What was actually checked

1. The supplied ZIP passed CRC and safe-path checks. SHA-256 of the input ZIP: `48ee152f9e18af0700d84b34cd5f22023f029a2eff56bdb8e22762edd8bce8e6`.
2. All 174 entries in its original SHA-256 manifest matched. Original files remain under `original-evidence/`; none was edited for this review.
3. Four core files were fetched again through GitHub at commit `c39fe2ba60e78790558c271f38e01ed300144abd`. Their bytes matched both the saved GitHub content and the Explorer-published implementation source set.
4. RPC request methods, selectors, destination addresses, block tags and response IDs were checked independently for the original and fresh mainnet-read captures. The EIP-1967 implementation slot and runtime byte identity were recomputed.
5. Raw local receipts, independently derived event topics, pending/claimable state, actual underlying transfers, burned shares and minted fee shares were reconciled for the original, replayed and fresh-fork scenarios.
6. The original scenario states and economic settlement events were reproduced by actual EVM execution using the preserved RPC journal. Missing saved replies cause failure; the wrapper has no network fallback. Unused random default Ganache wallets are omitted so no invented nonce responses are needed. Explicit test identities remain unchanged.
7. The unmodified original harness completed all five scenarios against a fresh live-RPC fork at block 12,602,402. A separate mainnet read at 12,602,387 confirmed the starting fixture and implementation. These are new snapshots, not replacement evidence for the original block.

## Evidence boundaries

| Observation | Block | What it establishes |
|---|---:|---|
| Original read-only identity/configuration capture | 12,556,781 | The named deployed vault, asset and implementation at that snapshot |
| Original read-only request probes | 12,557,052 | Pending requests, request boundaries and silo accounting at that snapshot |
| Original fork origin | 12,557,717 | Starting upstream state used for the five local scenarios |
| Supplied documentation-validation fork | 12,560,435 | A separate earlier validation run already included in the input ZIP |
| Supplied documentation-validation read/probes | 12,560,438 | Separate records already included in the input ZIP |
| Fresh review mainnet read | 12,602,387 | A new read-only check of implementation, asset and initial requests |
| Fresh review fork origin | 12,602,402 | A new five-scenario EVM run using live RPC state |
| Saved-state EVM replay | 12,557,717 | Reproducibility conditional on the supplied original RPC replies |

The original fork timestamp was 2026-10-15 14:35:38 UTC; the fresh fork timestamp was 2026-10-16 07:03:33 UTC. Different captures must not be described as one same-block observation or as uninterrupted monitoring between blocks.

## Article changes and reasons

- The lead now states that the successful call was the Safe's locally simulated settlement call. A reader should not confuse this with a real user's completed mainnet withdrawal.
- mREAL is identified as a deployed mock token near the beginning, with an explicit distinction from dollars, USDr and RLS. The onchain name is not used to authenticate an operator.
- The source states that ERC-7540 defines asynchronous request states, whereas the batch liquidity gate and SettleRedeem event are implementation-specific.
- The separate 1,100 mREAL of pending deposits is acknowledged. It was in the silo, not counted as available Safe liquidity, and these tests did not settle those deposits.
- Raw below-threshold receipts contain TotalAssetsExpirationUpdated. This is stronger and more precise than merely saying the wrapper might change state, while avoiding the false conclusion that the whole call had no effect.
- Cancellation is explicitly before the valuation proposal. The control is not presented as a way to cancel an already valuation-locked request.
- Cash settlement and claims are separated from share burns and fee mints. The 55 fee shares are not a 55-mREAL payout or an RLS burn.
- Fresh-fork repetition and offline replay are described separately. Replay is not promoted as a second independent mainnet observation.
- The runtime/source checks are not described as a clean compiler rebuild. Separate Explorer smart-contract metadata requests for the linked ERC7540Lib and FeeLib addresses returned HTTP 404; their source is included in the implementation's published source set, and captured executable code was compared across fork snapshots. Separate source-to-runtime verification of each linked library is not established.

## Information gained

The information gain is the controlled demonstration that B's 495-mREAL outcome depends on the current 5,445-mREAL batch requirement despite 1,000 mREAL already being available. The exact one-unit boundary, the same-liquidity cancellation control, raw transfer reconciliation and a new live-RPC fork repeat make this more than a documentation summary. Three graphics present distinct evidence: the causal comparison, all five outcomes, and cash/share accounting.

## What remains below a production demonstration

The underlying asset is a mock. Authorities are impersonated only locally. No production UI, operator process, real-credit repayment, end-user withdrawal, physical asset backing or full production integration was exercised. The batch behavior is observable in published source and is not presented as a new vulnerability. Neither saved-data checks nor RPC/Explorer agreement independently authenticate an Axyl consensus certificate.

A stronger follow-up, if a public and authorized environment permits it, would trace a current real issuance through requested, settled and paid states, with authenticated operator/product attribution and a documented custody/liquidity process. It should not be replaced with more assertion counts, decorative images or unlabelled simulations.

## Graphic placement

1. `figures/01-banner.png`: cover after the title/subtitle. It conveys the same 1,000-mREAL liquidity and different batch outcomes.
2. `figures/02-scenario-matrix.png`: after the five-scenario section. It keeps receipt success, settlement events and actual B payments separate.
3. `figures/03-cash-and-shares.png`: after the reconciliation section. It distinguishes underlying-token transfers from vault-share accounting.

Graphics use DAVID's pale grid, black panels, purple/lilac and chartreuse palette, clipped-corner geometry and restrained mono data labels. The original supplied multicolour Rayls mark is embedded unchanged with its black background. They contain no fabricated browser screenshots, account watermark or snapshot date. Block numbers retain the evidence boundary.
