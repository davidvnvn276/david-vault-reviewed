/* Local fork experiment. All transaction execution stays in the in-process VM.
 * The upstream adapter allows read-only RPC methods only. No private keys needed.
 */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const ganache = require('ganache');
const { Interface, keccak256 } = require('ethers');
const ROOT = path.resolve(__dirname, '..');
const OUT = path.resolve(process.argv[2] || path.join(ROOT, 'local-fork-result'));
fs.mkdirSync(OUT, { recursive: false });
const stringify = x => JSON.stringify(x, (_, v) => typeof v === 'bigint' ? v.toString() : v, 2);
const save = (name, data) => fs.writeFileSync(path.join(OUT, name), stringify(data) + '\n');
const V = '0xcc180cb4031de7c2ec3d4c16e36ede4c6550eda0';
const A = '0x4d76d208692c1b1c22d77350b89396d76c947e22';
const B = '0xc7e33057e72a5331e9ecbdd8159995de6c78f554';
const OTHER = '0x0000000000000000000000000000000000000001';
const metadata = JSON.parse(fs.readFileSync(path.join(ROOT, 'lagoon-logic-source.json')));
const eventAbi = 'event SettleRedeem(uint40 indexed epochId,uint40 indexed settledId,uint256 totalAssets,uint256 totalSupply,uint256 assetsWithdrawed,uint256 sharesBurned)';
const vi = new Interface([...metadata.abi, eventAbi]);
const ti = new Interface(['function balanceOf(address) view returns (uint256)',
  'function transfer(address,uint256) returns (bool)',
  'function approve(address,uint256) returns (bool)']);
const journal = [], results = [];
let provider, head;
const reads = new Set(['eth_chainId','net_version','web3_clientVersion','eth_blockNumber',
  'eth_getBlockByNumber','eth_getBlockByHash','eth_getCode','eth_getBalance',
  'eth_getStorageAt','eth_getTransactionCount','eth_getTransactionByHash',
  'eth_getTransactionReceipt','eth_getProof','eth_call','eth_getLogs']);
const upstream = { request: async ({method, params = []}) => {
  if (!reads.has(method)) throw Error('Upstream write forbidden: ' + method);
  const request = {jsonrpc:'2.0', id:journal.length+1, method, params};
  const response = await fetch('https://mainnet-rpc.rayls.com/', {
    method:'POST', headers:{'Content-Type':'application/json',
      'User-Agent':'DAVID-local-fork-research/1.0'}, body:JSON.stringify(request),
    signal:AbortSignal.timeout(30000)});
  if (!response.ok) throw Error('Upstream HTTP ' + response.status);
  const data = await response.json();
  journal.push({captured_utc:new Date().toISOString(), request, response:data});
  if (data.error) { const e=Error(data.error.message); Object.assign(e,data.error); throw e; }
  return data.result;
}};

async function run() {
  assert.equal(await upstream.request({method:'eth_chainId'}), '0x11cfd');
  head = await upstream.request({method:'eth_getBlockByNumber',params:['latest',false]});
  const tag = head.number;
  const remoteCall = async (fn,args=[]) => vi.decodeFunctionResult(fn,
    await upstream.request({method:'eth_call',params:[{to:V,data:vi.encodeFunctionData(fn,args)},tag]}))[0];
  const safe = (await remoteCall('safe')).toLowerCase();
  const asset = (await remoteCall('asset')).toLowerCase();
  let manager;
  try {
    await upstream.request({method:'eth_call',params:[{to:V,from:OTHER,
      data:vi.encodeFunctionData('updateNewTotalAssets',[11000n*10n**18n])},tag]});
    throw Error('Unexpected authorized outsider');
  } catch (error) {
    if (!error.data) throw error;
    const decoded = vi.parseError(error.data);
    assert.equal(decoded.name,'OnlyValuationManager'); manager=decoded.args[0].toLowerCase();
  }
  provider = ganache.provider({
    fork:{provider:upstream,blockNumber:Number(BigInt(tag)),requestsPerSecond:12},
    chain:{chainId:31337,networkId:31337,hardfork:'shanghai'},
    wallet:{unlockedAccounts:[A,B,safe,manager,OTHER]}, logging:{quiet:true}
  });
  assert.equal(await provider.request({method:'eth_chainId',params:[]}), '0x7a69');
  const rpc = (method,params=[]) => provider.request({method,params});
  const call = async (addr,iface,fn,args=[]) => iface.decodeFunctionResult(fn,
    await rpc('eth_call',[{to:addr,data:iface.encodeFunctionData(fn,args)},'latest']))[0];
  for (const address of new Set([A,B,safe,manager,OTHER]))
    await rpc('evm_setAccountBalance',[address,'0x56bc75e2d63100000']);
  const runtime = await rpc('eth_getCode',[metadata.address_hash || '0xd04deaba7fd06634764cbffe140011c69063ac77','latest']);
  assert.equal(runtime.toLowerCase(),metadata.deployed_bytecode.toLowerCase());
  const state = async () => ({
    walletA: await call(V,vi,'balanceOf',[A]), walletB:await call(V,vi,'balanceOf',[B]),
    pendingA:await call(V,vi,'pendingRedeemRequest',[0,A]),
    pendingB:await call(V,vi,'pendingRedeemRequest',[0,B]),
    claimableA:await call(V,vi,'maxWithdraw',[A]), claimableB:await call(V,vi,'maxWithdraw',[B]),
    supply:await call(V,vi,'totalSupply'),nav:await call(V,vi,'totalAssets'),
    assetA:await call(asset,ti,'balanceOf',[A]),assetB:await call(asset,ti,'balanceOf',[B]),
    assetSafe:await call(asset,ti,'balanceOf',[safe]),assetVault:await call(asset,ti,'balanceOf',[V])
  });
  const send = async (label,from,to,iface,fn,args,expected) => {
    assert.equal(await rpc('eth_chainId'),'0x7a69');
    const data=iface.encodeFunctionData(fn,args);
    const tx=await rpc('eth_sendTransaction',[{from,to,data,gas:'0x4c4b40',gasPrice:'0x174876e800'}]);
    const receipt=await rpc('eth_getTransactionReceipt',[tx]);
    save(label+'-receipt.json',receipt);
    assert.equal(Number(BigInt(receipt.status)),expected,label);
    results.push({label,status:receipt.status,tx});
    return receipt;
  };
  const start=await state(); save('initial-state.json',start);
  assert.equal(start.pendingA,5000n*10n**18n);assert.equal(start.pendingB,500n*10n**18n);
  let snap=await rpc('evm_snapshot');
  await send('cancel-A',A,V,vi,'cancelRequestRedeem',[A],1);
  let after=await state();save('after-cancel-A.json',after);
  assert.equal(after.walletA-start.walletA,5000n*10n**18n);
  assert.equal(after.pendingA,0n);assert.equal(after.supply,start.supply);
  await rpc('evm_revert',[snap]);snap=await rpc('evm_snapshot');
  await send('cancel-B',B,V,vi,'cancelRequestRedeem',[B],1);
  after=await state();save('after-cancel-B.json',after);
  assert.equal(after.walletB-start.walletB,500n*10n**18n);assert.equal(after.pendingB,0n);
  await rpc('evm_revert',[snap]);
  await send('cancel-outsider',OTHER,V,vi,'cancelRequestRedeem',[A],0);
  await send('claim-before-settlement',A,V,vi,'redeem',[10n**18n,A,A],0);
  assert.equal(stringify(await state()),stringify(start));
  assert.ok(start.assetA>=5500n*10n**18n,'Observed account A must hold enough mock units');
  const feeRates=await call(V,vi,'feeRates');
  const exitRate=BigInt(feeRates.exitRate);
  assert.equal(exitRate,100n,'Published fixture requires the captured 1% exit fee');
  const totalPending=start.pendingA+start.pendingB;
  const exitShares=(totalPending*exitRate+9999n)/10000n;
  const batchRequired=await call(V,vi,'convertToAssets(uint256)',[totalPending-exitShares]);
  assert.equal(batchRequired,5445n*10n**18n);
  const scenarios=[];
  let baseline=await rpc('evm_snapshot');
  for (const scenario of [
    {label:'zero',cash:0n},
    {label:'1000',cash:1000n*10n**18n},
    {label:'threshold-minus-one-wei',cash:batchRequired-1n},
    {label:'threshold',cash:batchRequired},
    {label:'1000-after-cancel-A',cash:1000n*10n**18n,cancelA:true}
  ]) {
    await rpc('evm_revert',[baseline]);baseline=await rpc('evm_snapshot');
    const prefix='cash-'+scenario.label;
    if(scenario.cancelA)await send(prefix+'-cancel-A',A,V,vi,'cancelRequestRedeem',[A],1);
    if(scenario.cash>0n)await send(prefix+'-fund-safe',A,asset,ti,'transfer',[safe,scenario.cash],1);
    await send(prefix+'-safe-approve',safe,asset,ti,'approve',[V,2n**256n-1n],1);
    await send(prefix+'-propose-nav',manager,V,vi,'updateNewTotalAssets',[11000n*10n**18n],1);
    const before=await state();save(prefix+'-before-settlement.json',before);
    const receipt=await send(prefix+'-settle',safe,V,vi,'settleRedeem',[11000n*10n**18n],1);
    const settled=await state();save(prefix+'-after-settlement.json',settled);
    const events=receipt.logs.map(log=>{try{const event=vi.parseLog(log);return event?{
      address:log.address,event:event.name,args:event.args.toArray()}:null;}catch{return null;}}).filter(Boolean);
    for(const [label,who] of [['A',A],['B',B]]) {
      const claimShares=await call(V,vi,'maxRedeem',[who]);
      if(claimShares>0n)await send(prefix+'-claim-'+label,who,V,vi,'redeem',[claimShares,who,who],1);
      else await send(prefix+'-claim-'+label+'-unavailable',who,V,vi,'redeem',[10n**18n,who,who],0);
    }
    const final=await state();save(prefix+'-after-claims.json',final);
    assert.equal(final.assetA-settled.assetA,settled.claimableA,'A received the displayed claimable amount');
    assert.equal(final.assetB-settled.assetB,settled.claimableB,'B received the displayed claimable amount');
    assert.equal(final.claimableA,0n);assert.equal(final.claimableB,0n);
    assert.equal(before.assetSafe-settled.assetSafe,settled.assetVault-before.assetVault,'Settlement transfer reconciles');
    assert.equal(settled.assetVault-final.assetVault,
      final.assetA-settled.assetA+final.assetB-settled.assetB,'Claim transfers reconcile');
    const settleEvents=events.filter(e=>e.event==='SettleRedeem');
    if(scenario.label==='threshold'){
      assert.equal(settleEvents.length,1);assert.equal(settled.pendingA,0n);assert.equal(settled.pendingB,0n);
      assert.equal(settled.claimableA,4950n*10n**18n);assert.equal(settled.claimableB,495n*10n**18n);
    }else if(scenario.cancelA){
      assert.equal(settleEvents.length,1);assert.equal(settled.claimableA,0n);
      assert.equal(settled.claimableB,495n*10n**18n);
    }else{
      assert.equal(settleEvents.length,0);assert.equal(settled.pendingA,start.pendingA);
      assert.equal(settled.pendingB,start.pendingB);assert.equal(settled.claimableA,0n);assert.equal(settled.claimableB,0n);
    }
    scenarios.push({label:scenario.label,cash_raw:scenario.cash,cancel_A:!!scenario.cancelA,before,settled,final,events});
  }
  const summary={status:'passed',scope:'LOCAL FORK; existing mock asset; simulated identities; no mainnet transactions',
    original_chain_id:72957,local_chain_id:31337,fork_block:Number(BigInt(tag)),fork_block_hash:head.hash,
    vault:V,asset,safe,valuation_manager:manager,implementation_runtime_keccak:keccak256(runtime),
    exit_rate_basis_points:exitRate,batch_required_assets_raw:batchRequired,
    initial:start,scenarios,transactions:results};
  save('summary.json',summary);console.log(stringify(summary));
}
run().catch(error=>{save('failure.json',{message:error.message,stack:error.stack,fork_block:head?.number});
  console.error(error.stack);process.exitCode=1;
}).finally(async()=>{save('upstream-read-journal.json',journal);if(provider)await provider.disconnect();});
