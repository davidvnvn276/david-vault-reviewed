# Research notes: Rayls vault withdrawal batches

Research date: 15 October 2026. These notes record the findings, evidence boundaries and editorial rationale behind DAVID's article.

## Research question and single angle

**Why Is My Vault Withdrawal Still Pending After a Successful Transaction? A Rayls Contract Test**

The investigation focuses on liquidity required by the current redemption batch and why a successful transaction receipt does not, by itself, prove that a withdrawal request was settled.

## Reproduced finding

Two controllers have pending requests in the same batch: A has 5,000 shares and B has 500 shares. With the captured conversion rate and 1% exit fee, the batch requires 5,445 mREAL.

1. **Safe balance: 0 mREAL.** The settlement call succeeds, but there is no SettleRedeem event or claimable asset amount.
2. **Safe balance: 1,000 mREAL.** The batch remains unprocessed, although this balance exceeds B's individual net amount of 495 mREAL.
3. **Safe balance: one smallest mREAL unit below 5,445 mREAL.** The batch remains unprocessed.
4. **Safe balance: exactly 5,445 mREAL.** The batch settles. Subsequent local claims pay 4,950 mREAL to A and 495 mREAL to B.
5. **Safe balance: 1,000 mREAL, after A cancels before the NAV proposal.** With A's larger request removed, B's request settles and B receives 495 mREAL.

Scenario 5 isolates the effect of batch size. This adds a controlled implementation-level finding beyond repeating the documented request, settlement and claim sequence.

## Mechanism reconciled with source

ERC7540Lib calculates the pending batch's post-fee obligation. If the required asset amount is zero or exceeds the Safe's token balance, the function returns before burning pending shares, transferring the settlement assets or emitting SettleRedeem. The wrapper may still complete valuation-related state updates. A status-1 receipt therefore does not establish that the redemption batch was processed.

FeeLib rounds the fee upward. The captured fixture uses exactly divisible amounts, giving a fee of 55 shares. Full settlement burns 5,500 pending shares and mints 55 fee shares, reducing supply from 11,000 to 5,555 shares. The fee must not be described as a separate underlying-token payment to the fee recipient: here it is represented through shares.

## Boundaries to state early

- The contract is deployed on Rayls mainnet, but its underlying asset is Mock Real Stable Coin, or mREAL. The name "AmFi CDI + 5%" alone does not authenticate an issuer or prove an available investment product.
- State-changing execution and payout reconciliation occur on local fork chain 31337. Mainnet queries are read-only. No real mainnet withdrawal is executed in this investigation.
- mREAL amounts are not USD, BRL, BRL1.p or USDr.
- Results concern the tested implementation, configuration and fixture. They do not establish that all vaults, all Lagoon versions or an actual AmFi investment product behave identically.
- Do not characterize the observation as a security vulnerability, lost funds, insolvency or evidence that real assets lack backing. The study identifies a batch-execution condition.
- Do not present local receipt hashes as mainnet transactions, or snapshot-reset scenarios as independent measurement days.

## Article structure

Open with the smaller request: B is entitled to 495 units after fees, yet 1,000 units in the Safe does not cover the current batch. Answer early that the tested implementation checks batch liquidity, then identify the mock asset and local-fork scope.

Introduce the Rayls/Lagoon context and the inspected deployment. Reconstruct the requests, present the five scenarios, explain the source and fee accounting, and reconcile receipts, events, maxWithdraw and actual token-balance changes. Finish with a practical withdrawal-verification method, the real public evidence link when available, and primary sources.

Keep the investigation on this one mechanism. Avoid unrelated ecosystem summaries, TPS comparisons and asset-pipeline figures. State the limitations clearly without repeating the same warning in every section.

## Suggested evidence visuals

1. A liquidity comparison: 1,000 mREAL available versus a 5,445-mREAL batch requirement. Label it as a local fork with a mock asset.
2. A causal comparison at the same 1,000-mREAL balance: A included in the batch versus A cancelled.
3. Four verification layers: receipt status, SettleRedeem event, maxWithdraw and actual recipient token-balance change.

Use untouched official logo assets. Render numbers and labels with precise tools rather than asking an image generator to invent evidence or redraw text.

## Contribution and scoring expectations

The work is relevant to vault withdrawal mechanics and Rayls/Lagoon distribution infrastructure. Its quality comes from exact integer arithmetic, source/runtime checks and reconciled states, events and receipts. Its original contribution is the controlled batch-size and liquidity-threshold experiment. The effort includes mainnet reads, historical event inspection, a fork of deployed state, five scenarios and a reproducible evidence package.

These provide grounds for a strong submission, not a guaranteed RP score. The principal limitation is the mock asset and local-fork environment: the study does not execute an actual withdrawal from an independently confirmed live investment vault.

## Deadline recorded from the supplied quest notice

The notice gives the weekly deadline as 18 October 2026 at 23:59 UTC, equivalent to 19 October at 06:59 UTC+7. The separate overall submission deadline of 30 October does not replace the weekly cutoff.
