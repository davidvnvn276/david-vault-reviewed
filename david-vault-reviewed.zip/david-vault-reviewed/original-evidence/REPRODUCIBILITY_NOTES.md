# Documentation and installation update, 15 October 2026

## Changes

README.md now provides a beginner walkthrough: extraction, tool installation, exact commands, expected results, manual receipt/event/balance checks, fresh-vs-saved evidence, source review, troubleshooting and public sharing. All distributed documentation is in English; research-notes.md records the research rationale, findings and evidence boundaries.

The Node lockfile marks `node_modules/ganache/node_modules/fsevents` as `optional: true`. Its parent Chokidar declares it optional, and fsevents is Darwin-only. The original clean `npm ci` failed on Linux with EBADPLATFORM; adding this one metadata flag allowed a clean install. All package versions, URLs and integrity fields are preserved. The original lockfile is at `provenance/package-lock.original.json`. This installation issue is not a vault-contract finding. See https://github.com/npm/cli/issues/7622 for the upstream optional/shrinkwrap issue.

The research harness, Python readers, offline verifier and all original raw evidence are unchanged. The refreshed manifest covers the new documentation and corrected installation metadata as well as the original evidence. A manifest is not an independent authentication signature.

## Validation scope

Clean-install validation used Linux, Python 3.12.14, Node v24.19.0 and npm 11.9.0. Windows/PowerShell was not available for native execution, so Windows command syntax is documented rather than represented as Windows-tested.

Checks include a clean pinned pip installation, corrected-lockfile npm ci, fresh mainnet reads, request probes and a successful five-scenario local fork. The documentation-validation fork originated at block 12,560,435; the read/probe validation used block 12,560,438. These do not replace original article captures at blocks 12,556,781 / 12,557,052 / 12,557,717, or turn local outcomes into production results.

Keep original evidence separate from fresh outputs. Do not disable assertions, remove fixture guards, overwrite historical observations or substitute zero for unavailable RPC responses just to obtain PASS.

Complete fresh validation requests, responses, receipts and states are retained under `validation/`, with a separate checks.json and README. The offline verifier's state assertions still target the original `data/` records; its manifest integrity check covers both distributed sets.

## English-only documentation edition

The documentation is consolidated into one detailed English README and English research notes. Language-specific duplicate documentation is omitted. Code, original observations and separate validation evidence are unchanged. The manifest is refreshed for these documentation changes.
