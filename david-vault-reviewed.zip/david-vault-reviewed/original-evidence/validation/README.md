# Documentation validation records

These are fresh clean-install validation outputs for the expanded README. They are separate from the original article evidence under ../data/.

The new mainnet read and request probes use block 12560438. The new local fork starts at block 12560435. State-changing execution remains local, chain ID 31337. These are not production withdrawals or additional original article samples.

checks.json records the tool versions, platform and verification outcome. The accompanying folders preserve the complete new raw requests, responses, receipts and before/after states. To manually review this fresh fork, use ../README.md section 6 with the summary/receipt paths changed to validation/local-fork/. The standard verify_saved.py checks all distributed file hashes, but its state assertions target the original ../data/ evidence.
