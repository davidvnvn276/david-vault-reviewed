#!/usr/bin/env python3
"""Offline consistency verifier for this research package. Python standard library only.
Checks hashes, request bindings and exact state/event/receipt reconciliation.
Does not authenticate RPC observations or a consensus certificate.
"""
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parent


def read(name):
    return json.loads((P / name).read_text())


def main():
    count = 0
    for line in (P / 'SHA256SUMS.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        f = P / name
        assert f.is_file(), f'Missing file: {name}'
        assert hashlib.sha256(f.read_bytes()).hexdigest() == digest, f'Changed file: {name}'
        count += 1
    print(f'PASS {count} manifest files present and unchanged')
    capture = read('data/mainnet-read/summary.json')
    assert capture['chain_id'] == 72957
    assert capture['asset_name'] == 'Mock Real Stable Coin'
    assert capture['asset_symbol'] == 'mREAL'
    assert capture['runtime_matches_explorer_metadata'] is True
    state = read('data/request-probe/summary.json')
    rows = state['rows']
    integer = lambda name: int(rows[name]['result'], 16)
    assert integer('A-balanceOf(address)') == 5000 * 10**18
    assert integer('B-balanceOf(address)') == 500 * 10**18
    assert integer('A-pendingRedeemRequest(uint256,address)') == 5000 * 10**18
    assert integer('B-pendingRedeemRequest(uint256,address)') == 500 * 10**18
    assert integer('A-maxWithdraw(address)') == integer('B-maxWithdraw(address)') == 0
    assert rows['cancel-A-authorized-simulation']['result'] == '0x'
    assert rows['cancel-B-authorized-simulation']['result'] == '0x'
    assert 'error' in rows['cancel-A-unapproved-caller']
    assert 'error' in rows['claim-A-before-settlement']
    assert 'error' in rows['claim-B-before-settlement']
    assert state['state_unchanged_after_simulations']
    for request in read('data/request-probe/request.json'):
        assert request['method'] == 'eth_call'
        assert int(request['params'][1], 16) == state['block']
    silo = {x['id']: int(x['result'], 16) for x in read('data/silo-response.json')}
    assert silo[1] == 5500 * 10**18
    assert silo[2] == 1100 * 10**18
    assert silo[3] == 11000 * 10**18
    assert integer('A-balanceOf(address)') + integer('B-balanceOf(address)') + silo[1] == silo[3]
    assert integer('A-pendingDepositRequest(uint256,address)') + integer('B-pendingDepositRequest(uint256,address)') == silo[2]
    print('PASS pinned account, pending-silo and share-supply reconciliation')
    source = read('data/source-comparison.json')
    assert len(source['checks']) == 4
    assert all(x['exact_match'] and x['github_sha256'] == x['explorer_sha256'] for x in source['checks'])
    print('PASS four exact pinned GitHub/Explorer source matches')
    local = read('data/local-fork/summary.json')
    assert local['status'] == 'passed'
    assert local['local_chain_id'] == 31337
    assert local['original_chain_id'] == 72957
    assert local['exit_rate_basis_points'] == '100'
    assert int(local['batch_required_assets_raw']) == 5445 * 10**18
    scenarios = {x['label']: x for x in local['scenarios']}
    assert len(scenarios) == 5
    for label in ['zero', '1000', 'threshold-minus-one-wei']:
        case = scenarios[label]
        assert not any(e['event'] == 'SettleRedeem' for e in case['events'])
        assert int(case['settled']['pendingA']) == 5000 * 10**18
        assert int(case['settled']['pendingB']) == 500 * 10**18
        assert int(case['settled']['claimableA']) == int(case['settled']['claimableB']) == 0
        receipt = read('data/local-fork/cash-' + label + '-settle-receipt.json')
        assert int(receipt['status'], 16) == 1
    assert int(scenarios['threshold-minus-one-wei']['cash_raw']) == 5445 * 10**18 - 1
    full = scenarios['threshold']
    assert int(full['settled']['claimableA']) == 4950 * 10**18
    assert int(full['settled']['claimableB']) == 495 * 10**18
    control = scenarios['1000-after-cancel-A']
    assert control['cancel_A']
    assert int(control['before']['pendingA']) == 0
    assert int(control['before']['pendingB']) == 500 * 10**18
    assert int(control['settled']['claimableB']) == 495 * 10**18
    for case in scenarios.values():
        settled, final = case['settled'], case['final']
        for holder in ['A', 'B']:
            assert int(final['asset' + holder]) - int(settled['asset' + holder]) == int(settled['claimable' + holder])
        assert int(final['claimableA']) == int(final['claimableB']) == 0
    for tx in local['transactions']:
        receipt = read('data/local-fork/' + tx['label'] + '-receipt.json')
        assert receipt['transactionHash'] == tx['tx']
        assert receipt['status'] == tx['status']
    print('PASS five local liquidity/queue scenarios, receipts, events and claim transfers')
    print('Scope: local-fork outcomes with an existing mock token; no production withdrawal or real-credit backing established.')


if __name__ == '__main__':
    main()
