# Why can a successful vault transaction leave a withdrawal pending?

Beginner reproduction guide for DAVID's Rayls/Lagoon vault investigation. Original evidence: 15 October 2026.

## 1. Choose a verification route

| Route | Purpose | Required software | Internet while running? |
| --- | --- | --- | --- |
| A: saved evidence | Check package hashes and reconcile the saved results | Python | No, after Python installation |
| B: fresh mainnet reads | Capture current vault state and simulate request boundaries | Python and the pinned Python dependency | Yes |
| C: fresh local fork | Execute the five liquidity scenarios again | Node.js, npm and the supplied lockfile | Yes |

Start with A. You do not have to complete all three at once. None requires a wallet, private key, seed phrase, real-token purchase, WSL or Docker. The research programs do not submit mainnet transactions.

### The question and result

Why can a successful settlement call leave a smaller request pending when the custodian has enough tokens for that request alone?

The captured current batch contains 5,000 and 500 pending shares. At the captured valuation and 1% exit fee it needs 5,445 mREAL. Local settlement calls succeed below that threshold without settling the batch. At exactly 5,445 mREAL, actual subsequent claims pay 4,950 and 495 mREAL. Cancelling the larger request makes 1,000 mREAL sufficient for the smaller one.

### Scope that must stay attached

The vault is deployed on Rayls mainnet, chain ID 72957. Its onchain name is **AmFi CDI + 5%**, but its underlying token is **Mock Real Stable Coin / mREAL**. A contract name does not authenticate its issuer or establish a live investment product.

Mainnet work is read-only. State-changing tests run in an in-process Ganache fork, chain ID 31337, using locally simulated authorities and the existing vault, linked libraries and mock token. No mainnet transaction is signed or submitted. This does not verify real credit backing, solvency, investment returns or production withdrawal performance, and does not describe every Lagoon version or Rayls vault.

## 2. Before typing commands

The main instructions use **Windows 10/11 PowerShell**. Unix equivalents appear near the end.

1. Copy only the contents of a command box. Do not copy the backticks or a prompt such as `PS C:\...>`.
2. Paste one command, press **Enter**, and wait for the next prompt before continuing.
3. Text labelled **expected output** is for comparison. Do not type it as a command.
4. Stop at the first unexplained failure. Troubleshooting is in section 11.
5. Keep the same PowerShell window open when using variables such as `$freshBlock`.

A **path** is a file/folder location. `Set-Location` or `cd` changes the working folder. A **script** is the supplied program. An **exit code** of zero means the process did not report a failure; it does not by itself authenticate a blockchain observation.

## 3. Download, extract and open the right folder

1. Download `david-vault-research-20261015.zip` and wait until the download finishes.
2. Press **Windows + E** to open File Explorer.
3. Create `C:\RaylsResearch` if it does not already exist.
4. Right-click the ZIP, select **Extract All**, and extract to that folder.
5. Open the extracted `david-vault-research-20261015` folder. You should see `README.md`, `verify_saved.py`, `read_vault.py`, `data` and `fork` together. If there is another same-named folder inside, open it instead.
6. Click File Explorer's address bar, type `powershell`, and press Enter to open a terminal there.

Alternatively, open PowerShell from Start and run:

```powershell
Set-Location "C:\RaylsResearch\david-vault-research-20261015"
```

Replace the quoted path if your extraction location differs. Do not work inside the ZIP preview or `C:\Windows\System32`.

```powershell
Get-Location
Test-Path .\verify_saved.py
Test-Path .\data\local-fork\summary.json
Test-Path .\fork\package-lock.json
```

The three `Test-Path` commands must print `True`. A `False` usually means a wrong folder or incomplete extraction.

## 4. Route A: verify the saved evidence first

### 4.1 Check or install Python

```powershell
py -3.12 --version
```

If it prints `Python 3.12.x`, continue. If not:

1. Open the official [Python Windows page](https://www.python.org/downloads/windows/).
2. Install the **Python Install Manager** from its official distribution.
3. Close and reopen PowerShell after installation; return to the package folder.
4. With the current manager, install the runtime:

```powershell
py install 3.12
```

5. Repeat `py -3.12 --version`. If a legacy launcher intercepts `py install`, use `pymanager install 3.12`; see the official [Windows instructions](https://docs.python.org/3/using/windows.html). Do not remove an existing working installation blindly.

Python 3.12 is the practical starting point used here; the validation environment ran 3.12.14. No prerelease is needed.

### 4.2 Run the offline verifier

```powershell
py -3.12 .\verify_saved.py
```

No pip package or Node installation is needed for this step. It uses the Python standard library.

Expected output, with `N` representing this distribution's manifest file count:

```text
PASS N manifest files present and unchanged
PASS pinned account, pending-silo and share-supply reconciliation
PASS four exact pinned GitHub/Explorer source matches
PASS five local liquidity/queue scenarios, receipts, events and claim transfers
Scope: local-fork outcomes with an existing mock token; no production withdrawal or real-credit backing established.
```

Immediately after the process finishes:

```powershell
$LASTEXITCODE
```

Expected: `0`. Do not add Python's `-O` option: it disables the assertions used by the verifier.

**PASS establishes internal consistency relative to the supplied files and manifest.** It does not authenticate the RPC provider, verify a consensus certificate or make the supplied manifest an independent signature. If files are unexpectedly changed/missing, re-extract a clean copy. Do not regenerate hashes just to conceal a mismatch.

## 5. Understand the saved files and amounts

| File | What it contains |
| --- | --- |
| `data/mainnet-read/summary.json` | Original vault identity, asset, implementation, block and runtime comparison |
| `data/request-probe/summary.json` | Block-pinned request state and read-only simulations |
| `data/local-fork/summary.json` | Original fork origin, five scenarios, states and local transaction list |
| `results.csv` | Compact original results using exact raw integer strings |
| `data/local-fork/*-receipt.json` | Individual local receipts, including status and raw logs |
| `data/source-comparison.json` | Four pinned source paths and their comparison hashes |
| `SHA256SUMS.txt` | Checksums for the distributed files |
| `REPRODUCIBILITY_NOTES.md` | Installation metadata correction and validation scope |
| `research-notes.md` | Research rationale, findings, scope boundaries and visual suggestions |
| `validation/README.md` | Complete fresh documentation-validation records, kept separate from original article samples |

Display a file using:

```powershell
Get-Content -Raw .\data\local-fork\summary.json
```

Or open the JSON in Notepad without saving accidental edits.

Amounts use 18 decimals. `495000000000000000000` raw units equals 495 mREAL. The threshold-minus-one value is `5444999999999999999999`, equal to **5,444.999999999999999999 mREAL**. This is one smallest mREAL unit, not a native gas-token wei. The code label `threshold-minus-one-wei` is retained for evidence continuity.

Do not convert long integer strings into floating-point numbers or ordinary Excel numeric cells: they may lose precision. The Python verifier and PowerShell BigInteger operations preserve exact integers.

| Scenario | Safe cash in mREAL | Settlement receipt | SettleRedeem event | Claimable A / B | Actual subsequent claim payments A / B |
| --- | ---: | --- | --- | --- | --- |
| `zero` | 0 | `0x1` | None | 0 / 0 | 0 / 0 |
| `1000` | 1,000 | `0x1` | None | 0 / 0 | 0 / 0 |
| `threshold-minus-one-wei` | 5,444.999999999999999999 | `0x1` | None | 0 / 0 | 0 / 0 |
| `threshold` | 5,445 | `0x1` | One | 4,950 / 495 | 4,950 / 495 |
| `1000-after-cancel-A` | 1,000 | `0x1` | One | 0 / 495 | 0 / 495 |

Claimable/payment columns are in mREAL. A cancelled before the valuation proposal in the last row. These are five reset local scenarios, not five mainnet withdrawals. Failed claim attempts have their own receipts.

## 6. Manually check a receipt, event and actual payment

This uses saved evidence. Section 9 explains how to inspect a fresh run instead.

### 6.1 Load the summary

```powershell
$studySummary = Get-Content -Raw .\data\local-fork\summary.json | ConvertFrom-Json
```

No printed output is normal: the result is stored in the variable.

### 6.2 Confirm success without settlement at 1,000 mREAL

```powershell
$receipt1000 = Get-Content -Raw .\data\local-fork\cash-1000-settle-receipt.json | ConvertFrom-Json
$receipt1000.status
```

Expected: `0x1`, meaning this local call did not revert.

```powershell
$case1000 = $studySummary.scenarios | Where-Object { $_.label -eq "1000" }
$case1000.settled.pendingB
$case1000.settled.claimableB
@($case1000.events | Where-Object { $_.event -eq "SettleRedeem" }).Count
```

Expected, in order: `500000000000000000000`, `0`, `0`. B still has 500 pending shares, zero claimable assets and no decoded SettleRedeem event in that receipt.

### 6.3 Confirm the exact-threshold claim and token delta

```powershell
$caseFull = $studySummary.scenarios | Where-Object { $_.label -eq "threshold" }
$caseFull.settled.claimableA
$caseFull.settled.claimableB
```

Expected: `4950000000000000000000` and `495000000000000000000`.

```powershell
[bigint]::Parse($caseFull.final.assetA) - [bigint]::Parse($caseFull.settled.assetA)
[bigint]::Parse($caseFull.final.assetB) - [bigint]::Parse($caseFull.settled.assetB)
```

Expected: the same two amounts. This compares balances immediately after settlement with balances after claims; earlier transfers funding the Safe are not counted as claim receipts.

```powershell
$caseFull.settled.assetVault
$caseFull.final.assetVault
$caseFull.settled.supply
```

Expected: `5445000000000000000000`, `0`, `5555000000000000000000`. The vault received 5,445 mREAL and then paid it out. Share supply became 5,555: 11,000 minus 5,500 burned plus 55 minted fee shares.

### 6.4 Check the cancellation control

```powershell
$caseControl = $studySummary.scenarios | Where-Object { $_.label -eq "1000-after-cancel-A" }
$caseControl.before.pendingA
$caseControl.before.pendingB
$caseControl.settled.claimableB
$caseControl.final.assetSafe
```

Expected: `0`, `500000000000000000000`, `495000000000000000000`, `505000000000000000000`. B becomes claimable after A is removed, and the Safe retains 505 mREAL after paying B.

Local transaction hashes can recur after snapshot resets because nonces/state are restored. Identify records by **scenario and receipt filename**. These hashes are not mainnet Explorer links.

## 7. Route B: obtain a new read-only mainnet snapshot

### 7.1 Create a Python environment

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe --version
```

The first command creates the `.venv` folder. Use the explicit executable path below; activation and execution-policy changes are unnecessary.

### 7.2 Install the pinned Python dependency

```powershell
.\.venv\Scripts\python.exe -m pip install -r .\requirements.txt
```

This installs `pycryptodome==3.23.0` for Ethereum Keccak selectors. `Requirement already satisfied` means it is already installed in that environment.

### 7.3 Read the vault and controllers

Paste this as one line:

```powershell
.\.venv\Scripts\python.exe .\read_vault.py --vault 0xcc180cb4031de7c2ec3d4c16e36ede4c6550eda0 --holder 0x4d76d208692c1b1c22d77350b89396d76c947e22 --holder 0xc7e33057e72a5331e9ecbdd8159995de6c78f554 --output fresh-vault-read-01
```

The holders are addresses to inspect, not accounts you import. Wait for the summary, then check `$LASTEXITCODE` is zero.

```powershell
$freshRead = Get-Content -Raw .\fresh-vault-read-01\summary.json | ConvertFrom-Json
$freshRead.chain_id
$freshRead.block
$freshRead.asset_name
$freshRead.asset_symbol
$freshRead.runtime_matches_explorer_metadata
```

The chain must be 72957. The original asset was mREAL and the runtime comparison was true. Compare the new asset address, implementation and requests with the saved case. The block number will normally differ. Changed state is a new observation, not permission to relabel the original article's measurements.

### 7.4 Simulate request boundaries at that same new block

```powershell
$freshBlock = $freshRead.block
.\.venv\Scripts\python.exe .\probe_requests.py --block $freshBlock --output fresh-request-probe-01
```

Check `$LASTEXITCODE`, then inspect:

```powershell
Get-Content -Raw .\fresh-request-probe-01\summary.json
```

The original capture allowed controller cancellation and rejected outsider cancellation/early claims. Some labelled `error` rows are therefore expected reverts. Compare each row, its block/hash and `state_unchanged_after_simulations`. The script records observations: a zero exit code alone does not assert that every fresh result matches the old fixture.

These calls use `eth_call`; `from` is a simulation parameter, not a signature or proof of key ownership. The repeated-state comparison is at the pinned block, not a promise that all future mainnet state remains unchanged.

### 7.5 Optional original-block query

```powershell
.\.venv\Scripts\python.exe .\probe_requests.py --block 12557052 --output historical-request-probe-01
```

The reader also accepts `--block 12556781` with its normal vault/holder arguments and a new output folder. Historical state may be pruned. Unavailable responses are not zero balances and do not mean the historical contract did not exist.

## 8. Route C: install dependencies and run a fresh local fork

### 8.1 Install Node.js

1. Open [nodejs.org/en/download](https://nodejs.org/en/download).
2. Choose the Node.js **24 LTS** series and the Windows installer matching your machine, normally x64 for Intel/AMD. ARM devices need the appropriate ARM64 installer.
3. Run the installer and keep Node.js/npm selected. Finish installation.
4. Close/reopen PowerShell and return to the package root.
5. Check:

```powershell
node --version
npm.cmd --version
```

Both must print versions. The clean validation ran Node v24.19.0 and npm 11.9.0 on Linux. Native Windows execution was not available in this environment; these Windows-compatible command forms are not a claim of a completed Windows test.

### 8.2 Install the locked Node packages

```powershell
npm.cmd ci --prefix fork --no-audit --no-fund
```

Wait until it finishes and check `$LASTEXITCODE` is zero. Package counts/timing can vary.

The direct dependencies are Ganache 7.9.2 and ethers 6.13.4. The included lockfile contains a narrowly scoped optional-macOS-dependency metadata fix, documented in `REPRODUCIBILITY_NOTES.md`; its original version is preserved in `provenance/`. Package versions/integrity fields are unchanged.

Use `npm.cmd` to avoid PowerShell's `npm.ps1` execution-policy issue. No global execution-policy change is needed.

### 8.3 Run five scenarios

`fresh-local-fork-01` must not already exist:

```powershell
node .\fork\fork_probe.cjs fresh-local-fork-01
```

The process can be quiet while reading upstream state. A native µWS warning may be followed by a JavaScript fallback; that warning alone is not a result. Wait for completion and check:

```powershell
$LASTEXITCODE
Test-Path .\fresh-local-fork-01\summary.json
Test-Path .\fresh-local-fork-01\failure.json
```

Expected: `0`, `True`, `False`.

The fork exists inside the Node process. There is no separate server/localhost port to configure. Accounts are unlocked and funded for gas only locally. The upstream adapter rejects transaction-submission methods. This does not establish possession of any real controller/Safe/manager keys.

**The fork starts from the latest Rayls block read at run time.** It does not automatically replay the original block 12,557,717. The supplied fork script has no historical-block argument; the Python reader's `--block` option does not apply to it.

The harness guards the implementation runtime, expected pending requests, 1% exit fee and calculated threshold. If the fixture changed, the run may stop. Do not weaken assertions to manufacture reproduction.

### 8.4 Check the fresh summary

```powershell
$freshFork = Get-Content -Raw .\fresh-local-fork-01\summary.json | ConvertFrom-Json
$freshFork.status
$freshFork.original_chain_id
$freshFork.local_chain_id
$freshFork.fork_block
$freshFork.scenarios.Count
```

Expected: `passed`, `72957`, `31337`, the new fork block, and `5`. A failure file means the experiment did not finish its checks. Preserve that failure and the journal, then use a new folder name for a retry.

## 9. Verify the fresh run's actual outcomes

`verify_saved.py` always checks the supplied evidence under `data/`. Re-running it does **not** check a newly generated folder.

To repeat section 6 against fresh evidence, first change the summary and receipt paths:

```powershell
$studySummary = Get-Content -Raw .\fresh-local-fork-01\summary.json | ConvertFrom-Json
$receipt1000 = Get-Content -Raw .\fresh-local-fork-01\cash-1000-settle-receipt.json | ConvertFrom-Json
$receipt1000.status
```

Now repeat the `$case1000`, `$caseFull` and `$caseControl` commands in section 6. Check exact claim deltas, events and supply as well as status.

Keep the complete new folder: raw receipts, before/after states, summary and `upstream-read-journal.json`. Keep its new block/date attached. Do not overwrite the original `data/local-fork` evidence with fresh results.

## 10. Source provenance and original blocks

| Original observation | Rayls block |
| --- | ---: |
| Mainnet read | 12,556,781 |
| Request probes and pending-silo accounting | 12,557,052 |
| Local-fork origin | 12,557,717 |

Original fork hash: `0x1de12e7246d400e7f71c39878b0ee9530bfe90edfd1adfc1af7f0ec0d6502677`. These are separate captures, not a single same-block observation.

The original silo held 5,500 pending shares and separately 1,100 mREAL of pending deposits. Do not add the two unit types as TVL.

For code review:

1. Open [the Explorer implementation](https://explorer.rayls.com/address/0xd04deaba7fd06634764cbffe140011c69063ac77?tab=contract) and compare its address with the mainnet-read summary.
2. Read `data/source-comparison.json`: it specifies four source paths and commit `c39fe2ba60e78790558c271f38e01ed300144abd`.
3. Open [that exact GitHub commit](https://github.com/hopperlabsxyz/lagoon-v0/tree/c39fe2ba60e78790558c271f38e01ed300144abd), not a moving default branch.
4. Search `settleRedeem` and `assetsInTheSafe` in `ERC7540Lib.sol`; inspect the insufficient-liquidity return.
5. Follow the wrapper in `Vault-v0.6.0.sol`, including its valuation/fee steps. No batch settlement does not mean all wrapper state is unchanged.
6. Check the `SettleRedeem` declaration in verified `primitives/Events.sol`. The vault-only ABI omits some library events. Raw logs are retained alongside decoded events.

Optionally download the pinned library independently:

```powershell
Invoke-WebRequest -Uri "https://raw.githubusercontent.com/hopperlabsxyz/lagoon-v0/c39fe2ba60e78790558c271f38e01ed300144abd/src/v0.6.0/libraries/ERC7540Lib.sol" -OutFile .\fresh-ERC7540Lib.sol
(Get-FileHash .\fresh-ERC7540Lib.sol -Algorithm SHA256).Hash.ToLowerInvariant()
```

Expected SHA-256: `d6ed82a0bd82561eddd878fb21a795dec09d0b6a3d38a4908518e576f1ac598e`. This compares new download bytes with a recorded hash. It is not a full compiler rebuild or verification of every repository/linked-library file.

## 11. Troubleshooting

| Symptom | Action |
| --- | --- |
| Command not recognized | Complete that tool's installation, reopen PowerShell, repeat its version check and return to the package root. |
| `>>>` prompt | You are inside Python. Type `exit()`, Enter, then run the full command at the PowerShell prompt. |
| File missing, `ENOENT`, or False from Test-Path | Check extraction and current folder. Do not run inside the ZIP. |
| `npm.ps1 cannot be loaded` | Use `npm.cmd`, not a global execution-policy change. |
| `No module named Crypto` | Install with the explicit `.venv` Python, and run the reader with that same executable. |
| `EEXIST` / `FileExistsError` | Keep old outputs; change the new folder name to `fresh-local-fork-02` or `fresh-vault-read-02`. |
| `EBADPLATFORM` for `fsevents` | Use the updated lockfile from this package. Do not substitute `--force`; see the documented metadata correction. |
| Package/lock mismatch during npm ci | Use a matching clean release; do not mix package.json/lockfiles or silently regenerate dependencies. |
| µWS warning followed by fallback | Wait for the actual exit code/summary; the warning alone is neither PASS nor FAIL. |
| Timeout / HTTP 429 / TLS error | Retain the error, check connectivity, wait and retry with a new folder. Do not disable TLS or convert an unavailable response to zero. |
| Historical state unavailable / null / missing trie node | Report historical state unavailable. Keep the dated original evidence; do not infer a zero balance. |
| Pending/fee/runtime assertion failure | The starting fixture may have changed. Stop and label a new study; do not relax guards to get PASS. |
| An error row inside probe JSON | Read its label. Some unauthorized/early-claim reverts are expected tests, unlike an interrupted process. |
| Missing summary or failure.json present | The new attempt is incomplete. Keep failure/journal files and use a new output name for retry. |

For an unexplained error retain the exact command, tool versions and error text. Do not change research assertions to suppress it.

## 12. macOS/Linux equivalents

Open a terminal at the package root. Use Python 3.12 and Node 24 LTS installed through a supported route. Run each line separately:

```bash
python3 verify_saved.py
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python read_vault.py --vault 0xcc180cb4031de7c2ec3d4c16e36ede4c6550eda0 --holder 0x4d76d208692c1b1c22d77350b89396d76c947e22 --holder 0xc7e33057e72a5331e9ecbdd8159995de6c78f554 --output fresh-vault-read-01
npm ci --prefix fork --no-audit --no-fund
node fork/fork_probe.cjs fresh-local-fork-01
```

Use `echo $?` immediately after a Unix process to inspect its exit code. The same fresh-folder and changed-state rules apply. Do not paste Windows executable paths into a Unix shell.

## 13. Recording and public sharing

For a video, show the root folder, tool versions, verifier and selected receipt/event/balance checks. A fresh run should show its actual new fork block, local chain ID, complete outcome and claim deltas. Opening saved JSON on screen is evidence review, not a recording of new execution.

For a public GitHub evidence link:

1. Keep this investigation separate from prior bridge/fee packages.
2. Upload source scripts, lockfile, README and research notes, data, provenance, results.csv and manifest.
3. Exclude `.venv`, `fork/node_modules`, caches and unrelated personal files. `.gitignore` assists local Git; browser uploads do not enforce it for you.
4. Preserve file bytes/line endings. Reformatting or checkout conversion can break hashes.
5. Prefer also attaching this unchanged ZIP as a release asset. No public repository URL is assumed or invented here.
6. Download your public ZIP into a new folder and run Route A again. Check loose-file checkouts separately if you publish them.
7. Put the real public evidence URL in the article. A private chat download link is not a public reproduction URL.

If publishing a fresh experiment, include its full output and new block/date separately. The distributed manifest does not automatically cover files readers generate later.

## 14. Primary sources and installation references

- [Rayls and Lagoon vault infrastructure](https://www.rayls.com/blog/rayls-and-lagoon-finance-institutional-grade-vaults-for-the-rayls-public-chain)
- [Lagoon deposit/withdrawal flows](https://docs.lagoon.finance/vault/deposit-and-withdraw-flows)
- [ERC-7540](https://eips.ethereum.org/EIPS/eip-7540)
- [Lagoon networks and addresses](https://docs.lagoon.finance/resources/networks-and-addresses)
- [Pinned Lagoon source](https://github.com/hopperlabsxyz/lagoon-v0/tree/c39fe2ba60e78790558c271f38e01ed300144abd)
- [Inspected vault](https://explorer.rayls.com/address/0xcc180cb4031de7c2ec3d4c16e36ede4c6550eda0)
- [Python Windows setup](https://docs.python.org/3/using/windows.html)
- [Python virtual environments](https://docs.python.org/3/library/venv.html)
- [Node.js download](https://nodejs.org/en/download)
- [npm ci](https://docs.npmjs.com/cli/v11/commands/npm-ci/)
- [npm optional OS-dependency issue](https://github.com/npm/cli/issues/7622)
