#!/usr/bin/env python3
"""Read-only, block-pinned Lagoon deployment inspection. Never signs/sends a transaction.

Install pycryptodome==3.23.0, then pass a chain-observed vault address.
Names and API listings do not authenticate an issuer or prove product availability.
"""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import urllib.request

from Crypto.Hash import keccak

RPC = 'https://mainnet-rpc.rayls.com/'
EXPLORER = 'https://explorer.rayls.com'
ZERO = '0x' + '0' * 40
IMPL_SLOT = '0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc'


def selector(signature):
    h = keccak.new(digest_bits=256)
    h.update(signature.encode())
    return h.hexdigest()[:8]


def word(value):
    if isinstance(value, str) and value.startswith('0x'):
        return value[2:].zfill(64)
    return f'{int(value):064x}'


def fetch(url, payload=None):
    body = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(url, data=body, headers={
        'User-Agent': 'DAVID-read-only-research/1.0', 'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=35) as response:
        return json.load(response)


def save(folder, name, data):
    (folder / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--vault', required=True)
    parser.add_argument('--holder', action='append', default=[],
                        help='Optional observed holder; repeat for multiple accounts')
    parser.add_argument('--block', type=int)
    parser.add_argument('--output', default='vault-read-capture')
    args = parser.parse_args()
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=False)
    vault = args.vault.lower()
    if len(vault) != 42 or not vault.startswith('0x'):
        raise ValueError('Pass a 20-byte vault address')
    int(vault[2:], 16)

    initial = [
        {'jsonrpc': '2.0', 'id': 1, 'method': 'eth_chainId', 'params': []},
        {'jsonrpc': '2.0', 'id': 2, 'method': 'eth_getBlockByNumber',
         'params': [hex(args.block) if args.block else 'latest', False]},
    ]
    save(out, 'initial-request.json', initial)
    initial_response = fetch(RPC, initial)
    save(out, 'initial-response.json', initial_response)
    initial_by_id = {x['id']: x for x in initial_response}
    if int(initial_by_id[1]['result'], 16) != 72957:
        raise RuntimeError('Unexpected chain ID')
    block = initial_by_id[2]['result']
    if block is None:
        raise RuntimeError('Block unavailable')
    tag = block['number']
    calls = []
    labels = []

    def add(label, method, params):
        labels.append(label)
        calls.append({'jsonrpc': '2.0', 'id': len(calls) + 1,
                      'method': method, 'params': params})

    def add_call(label, address, signature, values=(), caller=ZERO):
        add(label, 'eth_call', [{'to': address, 'from': caller,
                                'data': '0x' + selector(signature)
                                + ''.join(word(x) for x in values)}, tag])

    for function in ['name()', 'symbol()', 'version()', 'asset()', 'decimals()',
                     'safe()', 'owner()', 'totalAssets()', 'totalSupply()', 'syncMode()',
                     'isAsyncOnly()', 'isTotalAssetsValid()', 'paused()', 'feeRates()']:
        add_call(function, vault, function)
    add('vault-code', 'eth_getCode', [vault, tag])
    add('implementation-slot', 'eth_getStorageAt', [vault, IMPL_SLOT, tag])
    add_call('previewRedeem-one-share', vault, 'previewRedeem(uint256)', [10**18])
    add_call('previewSyncRedeem-one-share', vault, 'previewSyncRedeem(uint256)', [10**18])
    add_call('convertToAssets-one-share', vault, 'convertToAssets(uint256)', [10**18])
    for function in ['maxWithdraw(address)', 'maxRedeem(address)', 'balanceOf(address)']:
        add_call('zero-controller-' + function, vault, function, [ZERO])
    save(out, 'state-labels.json', labels)
    save(out, 'state-request.json', calls)
    responses = fetch(RPC, calls)
    save(out, 'state-response.json', responses)
    by_id = {x['id']: x for x in responses}
    states = {label: by_id[c['id']] for label, c in zip(labels, calls)}

    def result(label):
        value = states[label]
        if 'error' in value:
            raise RuntimeError(f'{label}: {value["error"]}')
        if value.get('result') is None:
            raise RuntimeError(f'{label}: result unavailable')
        return value['result']

    def address(label):
        return '0x' + result(label)[-40:]

    def uint(label):
        return int(result(label), 16)

    def text(label):
        raw = bytes.fromhex(result(label)[2:])
        offset = int.from_bytes(raw[:32])
        size = int.from_bytes(raw[offset:offset + 32])
        return raw[offset + 32:offset + 32 + size].decode('utf-8')

    asset, safe, owner = address('asset()'), address('safe()'), address('owner()')
    implementation = address('implementation-slot')
    summary = {
        'captured_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'scope': 'Read-only inspection of an indexed deployment; issuer/product identity unconfirmed.',
        'chain_id': 72957, 'block': int(tag, 16), 'block_hash': block['hash'],
        'block_timestamp_utc': dt.datetime.fromtimestamp(int(block['timestamp'], 16), dt.timezone.utc).isoformat(),
        'vault': vault, 'name': text('name()'), 'symbol': text('symbol()'),
        'version': text('version()'), 'asset': asset, 'safe': safe, 'owner': owner,
        'implementation': implementation,
        'total_assets_raw': str(uint('totalAssets()')),
        'total_supply_raw': str(uint('totalSupply()')),
        'share_decimals': uint('decimals()'),
        'sync_mode_raw': uint('syncMode()'),
        'async_only': bool(uint('isAsyncOnly()')),
        'total_assets_valid': bool(uint('isTotalAssetsValid()')),
        'paused': bool(uint('paused()')),
        'simulated_calls': {k: states[k] for k in [
            'previewRedeem-one-share', 'previewSyncRedeem-one-share',
            'convertToAssets-one-share']},
    }
    calls, labels = [], []
    accounts = [('vault', vault), ('safe', safe), ('owner', owner)]
    accounts += [(f'holder-{i}', a.lower()) for i, a in enumerate(args.holder, 1)]
    for label, addr in accounts:
        add_call('asset-balance-' + label, asset, 'balanceOf(address)', [addr])
        add_call('share-balance-' + label, vault, 'balanceOf(address)', [addr])
        add_call('claimable-assets-' + label, vault, 'maxWithdraw(address)', [addr])
        add_call('pending-redeem-' + label, vault, 'pendingRedeemRequest(uint256,address)', [0, addr])
    for function in ['name()', 'symbol()', 'decimals()', 'totalSupply()']:
        add_call('asset-' + function, asset, function)
    add('implementation-code', 'eth_getCode', [implementation, tag])
    save(out, 'balances-labels.json', labels)
    save(out, 'balances-request.json', calls)
    responses = fetch(RPC, calls)
    save(out, 'balances-response.json', responses)
    by_id = {x['id']: x for x in responses}
    states = {label: by_id[c['id']] for label, c in zip(labels, calls)}
    summary['asset_name'] = text('asset-name()')
    summary['asset_symbol'] = text('asset-symbol()')
    summary['asset_decimals'] = uint('asset-decimals()')
    summary['asset_total_supply_raw'] = str(uint('asset-totalSupply()'))
    summary['balances_and_requests'] = {
        label: str(uint(label)) for label in labels
        if label.startswith(('asset-balance-', 'share-balance-', 'claimable-assets-', 'pending-redeem-'))}
    meta = fetch(EXPLORER + '/api/v2/smart-contracts/' + implementation)
    save(out, 'implementation-explorer.json', meta)
    runtime = result('implementation-code')
    summary['runtime_matches_explorer_metadata'] = runtime.lower() == meta.get('deployed_bytecode', '').lower()
    summary['runtime_sha256'] = hashlib.sha256(bytes.fromhex(runtime[2:])).hexdigest()
    if not summary['runtime_matches_explorer_metadata']:
        raise RuntimeError('Runtime does not match Explorer metadata')
    save(out, 'summary.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
