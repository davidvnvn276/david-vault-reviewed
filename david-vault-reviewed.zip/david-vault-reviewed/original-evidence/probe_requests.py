#!/usr/bin/env python3
"""Pinned read-only simulations of observed pending requests. No keys/transactions."""
import argparse
import datetime as dt
import json
from pathlib import Path
from read_vault import RPC, ZERO, fetch, save, selector, word

VAULT = '0xcc180cb4031de7c2ec3d4c16e36ede4c6550eda0'
A = '0x4d76d208692c1b1c22d77350b89396d76c947e22'
B = '0xc7e33057e72a5331e9ecbdd8159995de6c78f554'
OTHER = '0x' + '0' * 39 + '1'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--block', type=int)
    parser.add_argument('--output', default='request-probe-capture')
    args = parser.parse_args()
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=False)
    initial_request = {'jsonrpc': '2.0', 'id': 1, 'method': 'eth_getBlockByNumber',
                       'params': [hex(args.block) if args.block else 'latest', False]}
    initial = fetch(RPC, initial_request)
    save(out, 'initial-request.json', initial_request)
    save(out, 'initial-response.json', initial)
    block = initial['result']
    tag = block['number']
    requests, labels = [], []

    def add(label, function, values=(), caller=ZERO):
        labels.append(label)
        requests.append({'jsonrpc': '2.0', 'id': len(requests) + 1, 'method': 'eth_call',
                         'params': [{'to': VAULT, 'from': caller,
                                     'data': '0x' + selector(function)
                                     + ''.join(word(x) for x in values)}, tag]})

    for label, account in [('A', A), ('B', B)]:
        for function in ['balanceOf(address)', 'maxWithdraw(address)', 'maxRedeem(address)']:
            add(label + '-' + function, function, [account])
        for function in ['pendingRedeemRequest(uint256,address)',
                         'claimableRedeemRequest(uint256,address)',
                         'pendingDepositRequest(uint256,address)',
                         'claimableDepositRequest(uint256,address)']:
            add(label + '-' + function, function, [0, account])
    add('A-operator-other', 'isOperator(address,address)', [A, OTHER])
    add('cancel-A-authorized-simulation', 'cancelRequestRedeem(address)', [A], A)
    add('cancel-B-authorized-simulation', 'cancelRequestRedeem(address)', [B], B)
    add('cancel-A-unapproved-caller', 'cancelRequestRedeem(address)', [A], OTHER)
    add('claim-A-before-settlement', 'redeem(uint256,address,address)', [10**18, A, A], A)
    add('claim-B-before-settlement', 'redeem(uint256,address,address)', [10**18, B, B], B)
    add('withdraw-A-before-settlement', 'withdraw(uint256,address,address)', [10**18, A, A], A)
    add('zero-share-request-A', 'requestRedeem(uint256,address,address)', [0, A, A], A)
    add('request-A-more-than-wallet', 'requestRedeem(uint256,address,address)', [6000*10**18, A, A], A)
    add('change-sync-mode-unapproved-caller', 'setSyncMode(uint8)', [0], OTHER)
    save(out, 'labels.json', labels)
    save(out, 'request.json', requests)
    response = fetch(RPC, requests)
    save(out, 'response.json', response)
    by_id = {x['id']: x for x in response}
    rows = {label: by_id[i] for i, label in enumerate(labels, 1)}
    check_request = [r for r, label in zip(requests, labels) if label.startswith(('A-', 'B-'))]
    after = fetch(RPC, check_request)
    save(out, 'unchanged-state-request.json', check_request)
    save(out, 'unchanged-state-response.json', after)
    same = all(x.get('result') == by_id[x['id']].get('result')
               and x.get('error') == by_id[x['id']].get('error') for x in after)
    summary = {'captured_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
               'block': int(tag, 16), 'block_hash': block['hash'],
               'scope': 'eth_call caller simulations, not transactions or evidence of key possession',
               'state_unchanged_after_simulations': same, 'rows': rows}
    save(out, 'summary.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
