# How Does Batch Settlement Work in a Vault? Five Local-Fork Tests on Rayls

*An implementation study using mock mREAL, with settlement, claimable state and token transfers checked separately.*

This article examines batch settlement through five local-fork scenarios on a Lagoon deployment on Rayls using **mREAL, a mock asset**. The inspected deployment has not been linked to the newly announced BRL1.p launch-deposit process. These tests do not establish how the planned investment vault will handle withdrawals.

[Rayls’ 15 October announcement](https://www.rayls.com/blog/first-vault-on-rayls-launch-deposits-open) describes BRL1.p launch deposits before transfers into the investment vault, with full vault terms to precede those transfers.

Within the inspected mock-asset deployment, I tested the Safe’s settlement call. With **1,000 mREAL available**, a 500-share request worth **495 mREAL after fees** remained pending because the current redemption batch required **5,445 mREAL**.

After the larger request in the same batch was cancelled before the valuation proposal, the same 1,000 mREAL was sufficient for the remaining request to settle and be claimed.

The experiment illustrates how one implementation processes a batch. It does not report a customer withdrawal incident.

## Deployment and test boundaries

[Rayls’ Lagoon partnership announcement](https://www.rayls.com/blog/rayls-and-lagoon-finance-institutional-grade-vaults-for-the-rayls-public-chain) provides context for studying controlled deposits, redemptions and valuation. It does not authenticate this deployment as a contract serving a particular commercial product.

The inspected vault is [`0xcc180cb4031de7c2ec3d4c16e36ede4c6550eda0`](https://explorer.rayls.com/address/0xcc180cb4031de7c2ec3d4c16e36ede4c6550eda0), on Rayls mainnet, chain ID **72957**. Its onchain name is “AmFi CDI + 5%.” Its underlying asset, however, identifies itself as **“Mock Real Stable Coin,” symbol mREAL, with 18 decimals**. The vault's name does not authenticate its operator or establish that it is a live investment product. All asset amounts below are units of mock mREAL.

All mainnet inspection was read-only. The five original scenarios ran in Ganache, local chain ID **31337**, forked from Rayls block **12,557,717**, timestamped **15 October 2026, 14:35:38 UTC**. The fork retained the existing vault, linked-library bytecode, pending requests and mock token. It locally unlocked the controller, Safe and valuation-manager addresses to exercise their permissions; this does not establish possession of their real keys. Mock-token funding came from an existing controller balance. No mainnet transaction was signed or submitted.

Four core source files published with the Explorer implementation matched Lagoon commit [`c39fe2ba60e78790558c271f38e01ed300144abd`](https://github.com/hopperlabsxyz/lagoon-v0/tree/c39fe2ba60e78790558c271f38e01ed300144abd): the vault wrapper, ERC7540 contract, ERC7540 library and configuration enums. The deployed implementation's RPC runtime bytes also matched Explorer's published runtime. This was a source comparison and runtime identity check, **not an independent compiler rebuild of the implementation and every linked library**.

## A request, a settlement and a payment are different outcomes

[ERC-7540](https://eips.ethereum.org/EIPS/eip-7540) separates asynchronous requests into Pending, Claimable and Claimed states. It does not prescribe the liquidity threshold tested here or require Lagoon's particular settlement event.

The fork began with two pending redemption requests in the same batch:

- Controller A: **5,000 shares**.
- Controller B: **500 shares**.

Neither had a claimable redemption. A's remaining wallet balance was 5,000 shares and B's was 500; together with the 5,500 requested shares in the pending silo, these reconciled to all **11,000 outstanding shares**.

Stored total assets were also 11,000 mREAL. That valuation was distinct from the mock tokens available in the assets custodian, which the implementation calls the Safe. The evidence separately records 1,100 mREAL of pending deposits in the silo. Those were not the Safe's available balance, and this experiment did not settle those deposits.

## What liquidity does this implementation require?

The inspected [`ERC7540Lib.settleRedeem`](https://github.com/hopperlabsxyz/lagoon-v0/blob/c39fe2ba60e78790558c271f38e01ed300144abd/src/v0.6.0/libraries/ERC7540Lib.sol) calculates assets required for the **current redemption batch**, after its exit fee. It compares that requirement with the underlying-token balance of the Safe.

If the batch requires more assets than the Safe holds, the library returns early instead of reverting the outer call. In this configuration the exit fee was **100 basis points, or 1%**. With the tested valuation and supply:

**5,500 pending shares − 55 exit-fee shares = 5,445 net shares, corresponding to 5,445 mREAL.**

The 55-share fee was represented by shares minted during settlement. It was not a separate 55-mREAL cash payment.

The [`vault wrapper`](https://github.com/hopperlabsxyz/lagoon-v0/blob/c39fe2ba60e78790558c271f38e01ed300144abd/src/v0.6.0/vault/Vault-v0.6.0.sol) also performs valuation and fee-related steps before attempting batch settlement. The below-threshold receipts contained `TotalAssetsExpirationUpdated`, despite containing no `SettleRedeem`. Calling the transaction a complete no-op would therefore be inaccurate.

## Five controlled scenarios

Each scenario began from a reset snapshot. I held the proposed valuation and authorized workflow constant, varied the Safe’s liquidity, then used cancellation to change the batch size.

**1. Safe balance: 0 mREAL.**

The settlement call returned status 1 without a `SettleRedeem` event. Both requests remained pending, with no claimable amount created for either controller.

**2. Safe balance: 1,000 mREAL.**

The call again returned status 1 without settling the batch. B’s individual post-fee amount was 495 mREAL, but the current batch required 5,445 mREAL. B’s request remained pending in this local scenario, with no claimable amount created.

**3. Safe balance: 5,444.999999999999999999 mREAL.**

This was one smallest mREAL unit below the requirement. The call returned status 1, but neither request became claimable. The tested path did not partially process the batch at that boundary.

**4. Safe balance: exactly 5,445 mREAL.**

The batch settled and emitted `SettleRedeem`. A became entitled to 4,950 mREAL and B to 495 mREAL. Subsequent local claim transactions increased their actual underlying-token balances by exactly those amounts.

**5. Safe balance: 1,000 mREAL, after A cancelled.**

A cancelled its 5,000-share request **before the valuation proposal**. With only B’s 500-share request remaining, settlement succeeded and B claimed 495 mREAL. The Safe retained **505 mREAL**. Cancellation returned A’s shares; it did not pay A underlying tokens.

The fifth scenario isolates the batch effect: Safe liquidity was the same 1,000 mREAL as in the second scenario, while the current batch requirement fell from 5,445 to 495 mREAL. B’s request then became claimable. Subsequent claims verified the corresponding token transfer.

For the first three scenarios, no `SettleRedeem` event appeared and subsequent claim attempts reverted because the requests were not claimable.

This is a result for the captured implementation and configuration. ERC-7540 does not impose this particular batch-liquidity rule on every vault.

## Did the tokens and shares actually reconcile?

At the exact threshold, raw token-transfer logs and balance changes showed **5,445 mREAL moving from the Safe to the vault**. Separate claim transactions then transferred **4,950 to A and 495 to B**, leaving the vault's underlying-token balance at zero.

Shares reconciled independently:

**11,000 initial shares − 5,500 burned pending shares + 55 minted fee shares = 5,555 outstanding shares.**

The raw share-token logs showed the 5,500-share burn and fee mints totalling 55. These burns concerned vault shares; the underlying mREAL moved through transfers.

Additional controls confirmed that authorized controller cancellations returned the corresponding shares without underlying-token payments. Outsider cancellation and a claim attempted before settlement reverted.

I decoded `SettleRedeem` using its declaration in the published library event source because it was absent from the main vault ABI. Raw receipts remain available alongside decoded events and before-and-after state; the finding does not depend solely on a generated summary.

## Could the result be reproduced?

A review repeated the complete five-scenario harness on a fresh fork originating at Rayls block **12,602,402**, timestamped **16 October 2026, 07:03:33 UTC**. The same liquidity boundaries and payments held. A separate read-only capture at block **12,602,387** confirmed the implementation, mock-asset identity and starting request state.

The review also re-executed the original scenarios in the EVM using the preserved upstream RPC replies, with no live-network fallback. The scenario states and economic settlement events matched. This saved-state replay makes the experiment rerunnable if historical RPC state becomes unavailable; it does **not** independently authenticate the saved RPC observations.

The evidence package includes the unchanged original records, pinned source comparisons, fresh review captures, raw receipts, exact-integer checks and replay instructions. Its English README separates three tasks: checking saved evidence, re-executing the captured fork, and obtaining a new live RPC snapshot. The original fork harness starts from the latest available block; its fixture guards may stop a fresh run if requests or configuration change.

The [public evidence repository](https://github.com/davidvnvn276/david-vault-reviewed) contains the ZIP and step-by-step README. Readers can inspect raw receipts, reconcile balances, run the saved-state replay or repeat the five scenarios on a local fork. No wallet or private key is required; state-changing execution stays local with mock mREAL.

## How should an interface represent these states?

The local tests show why an interface should read the request state as well as the settlement transaction receipt. In the captured configuration, the current batch determined the liquidity requirement.

A useful interface should distinguish:

- **Pending:** the request is recorded but has not become claimable.
- **Claimable:** the controller can claim the settled amount, verified through request state and the implementation's available-claim reads.
- **Paid:** a successful claim transferred the underlying tokens to the intended recipient.

An event can support the settlement check; the final asset transfer supports the payment check. Neither should be inferred from the receipt's success flag alone.

This investigation does not establish real-world credit backing, solvency, investment returns or production withdrawal performance. It tests a deployed implementation with a mock underlying asset and locally simulated authorities. It also does not establish that every Lagoon version, Rayls vault or withdrawal path has the same behavior.

The implementation lesson is precise: **batch settlement, claimable state and the final asset transfer are separate outcomes.** Applying that lesson to a live product requires its authenticated contract addresses, configuration and published terms.

## Sources and onchain references

- [Rayls: first-vault launch deposits announcement](https://www.rayls.com/blog/first-vault-on-rayls-launch-deposits-open)
- [Rayls and Lagoon Finance partnership](https://www.rayls.com/blog/rayls-and-lagoon-finance-institutional-grade-vaults-for-the-rayls-public-chain)
- [ERC-7540: Asynchronous ERC-4626 Tokenized Vaults](https://eips.ethereum.org/EIPS/eip-7540)
- [Lagoon deposit and redemption flows](https://docs.lagoon.finance/vault/deposit-and-withdraw-flows)
- [Inspected vault](https://explorer.rayls.com/address/0xcc180cb4031de7c2ec3d4c16e36ede4c6550eda0)
- [Published implementation source](https://explorer.rayls.com/address/0xd04deaba7fd06634764cbffe140011c69063ac77?tab=contract)
- [Underlying mREAL token](https://explorer.rayls.com/address/0x4a10003baaafbfbfb460bb6d4d597f107781e900)
- [Pinned ERC7540 library](https://github.com/hopperlabsxyz/lagoon-v0/blob/c39fe2ba60e78790558c271f38e01ed300144abd/src/v0.6.0/libraries/ERC7540Lib.sol)
- [Pinned vault wrapper](https://github.com/hopperlabsxyz/lagoon-v0/blob/c39fe2ba60e78790558c271f38e01ed300144abd/src/v0.6.0/vault/Vault-v0.6.0.sol)

@RaylsLabs
